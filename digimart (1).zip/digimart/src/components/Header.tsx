'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Products', href: '/products' },
  { label: 'Categories', href: '/products' },
  { label: 'Sellers', href: '/products' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartCount] = useState(3);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      const handleScroll = () => setMenuOpen(false);
      window.addEventListener('scroll', handleScroll, { passive: true });
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, [menuOpen]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'glass-nav shadow-sm border-b border-border/50 py-2'
            : 'bg-transparent py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 min-w-0">
            <AppLogo size={36} />
            <span className="font-extrabold text-xl tracking-tight text-foreground hidden sm:block">
              DigiMart
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks?.map((link) => (
              <Link
                key={link?.label}
                href={link?.href}
                className="px-4 py-2 text-sm font-semibold text-muted-foreground hover:text-foreground rounded-lg hover:bg-muted transition-all duration-200"
              >
                {link?.label}
              </Link>
            ))}
          </nav>

          {/* Right CTAs */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <button
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full bg-muted text-muted-foreground text-sm hover:bg-border transition-colors"
              aria-label="Search products"
            >
              <Icon name="MagnifyingGlassIcon" size={16} />
              <span className="hidden lg:block">Search products…</span>
            </button>

            {/* Cart */}
            <button
              className="relative p-2.5 rounded-full hover:bg-muted transition-colors"
              aria-label={`Cart with ${cartCount} items`}
            >
              <Icon name="ShoppingCartIcon" size={22} className="text-foreground" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Login */}
            <Link
              href="/products"
              className="hidden sm:flex btn-secondary !py-2 !px-5 !text-sm"
            >
              Sign In
            </Link>

            {/* Admin */}
            <Link
              href="/admin-dashboard"
              className="hidden md:flex btn-primary !py-2 !px-5 !text-sm"
            >
              Admin
            </Link>

            {/* Hamburger */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
            >
              <Icon name={menuOpen ? 'XMarkIcon' : 'Bars3Icon'} size={24} className="text-foreground" />
            </button>
          </div>
        </div>
      </header>
      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-foreground/20 backdrop-blur-sm"
            onClick={() => setMenuOpen(false)}
          />
          <div className="absolute top-0 left-0 right-0 bg-card border-b border-border pt-20 pb-6 px-6 shadow-xl">
            <nav className="flex flex-col gap-1">
              {navLinks?.map((link) => (
                <Link
                  key={link?.label}
                  href={link?.href}
                  onClick={() => setMenuOpen(false)}
                  className="px-4 py-3 text-base font-semibold text-foreground hover:text-primary hover:bg-muted rounded-xl transition-all"
                >
                  {link?.label}
                </Link>
              ))}
              <div className="mt-4 pt-4 border-t border-border flex flex-col gap-3">
                <Link href="/products" onClick={() => setMenuOpen(false)} className="btn-secondary !justify-center">
                  Sign In
                </Link>
                <Link href="/admin-dashboard" onClick={() => setMenuOpen(false)} className="btn-primary !justify-center">
                  Admin Panel
                </Link>
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}