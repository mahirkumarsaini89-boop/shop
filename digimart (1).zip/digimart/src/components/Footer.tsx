import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

const footerLinks = [
  { label: 'Products', href: '/products' },
  { label: 'Categories', href: '/products' },
  { label: 'Sell on DigiMart', href: '/products' },
  { label: 'Privacy', href: '/' },
  { label: 'Terms', href: '/' },
];

const socialLinks = [
  { icon: 'GlobeAltIcon', label: 'Website', href: '/' },
  { icon: 'ChatBubbleLeftRightIcon', label: 'Twitter', href: '/' },
  { icon: 'CameraIcon', label: 'Instagram', href: '/' },
];

export default function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo + Copyright */}
          <div className="flex items-center gap-3">
            <AppLogo size={32} />
            <span className="font-extrabold text-lg text-foreground">DigiMart</span>
            <span className="text-muted-foreground text-sm font-medium ml-2">
              © 2026 DigiMart Inc.
            </span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap items-center justify-center gap-x-8 gap-y-2">
            {footerLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Social Icons */}
          <div className="flex items-center gap-3">
            {socialLinks.map((s) => (
              <Link
                key={s.label}
                href={s.href}
                aria-label={s.label}
                className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-all"
              >
                <Icon name={s.icon as 'GlobeAltIcon'} size={16} />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}