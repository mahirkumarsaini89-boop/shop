import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  return [
    { url: baseUrl, lastModified: new Date('2026-05-11'), changeFrequency: 'daily', priority: 1.0 },
    { url: `${baseUrl}/products`, lastModified: new Date('2026-05-11'), changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/admin-dashboard`, lastModified: new Date('2026-05-11'), changeFrequency: 'weekly', priority: 0.5 },
  ];
}