'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from
'recharts';
import AppLogo from '@/components/ui/AppLogo';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const SALES_DATA = [
{ month: 'Jan', revenue: 182000, orders: 3240, users: 1820 },
{ month: 'Feb', revenue: 215000, orders: 3890, users: 2100 },
{ month: 'Mar', revenue: 198000, orders: 3560, users: 1950 },
{ month: 'Apr', revenue: 267000, orders: 4780, users: 2650 },
{ month: 'May', revenue: 312000, orders: 5620, users: 3100 },
{ month: 'Jun', revenue: 289000, orders: 5190, users: 2870 },
{ month: 'Jul', revenue: 345000, orders: 6230, users: 3420 },
{ month: 'Aug', revenue: 398000, orders: 7150, users: 3950 },
{ month: 'Sep', revenue: 421000, orders: 7580, users: 4180 },
{ month: 'Oct', revenue: 456000, orders: 8210, users: 4520 },
{ month: 'Nov', revenue: 512000, orders: 9240, users: 5080 },
{ month: 'Dec', revenue: 589000, orders: 10620, users: 5840 }];


const CATEGORY_DATA = [
{ name: 'Software', value: 38, fill: '#FF3D57' },
{ name: 'Courses', value: 24, fill: '#7B2FFF' },
{ name: 'Templates', value: 19, fill: '#FF6B2B' },
{ name: 'Media', value: 11, fill: '#F59E0B' },
{ name: 'E-Books', value: 8, fill: '#10B981' }];


const RECENT_ORDERS = [
{ id: '#ORD-78921', customer: 'Arjun Mehta', product: 'React Next.js 15 Starter Kit', amount: 89, status: 'Completed', date: '2026-05-11', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1d4884314-1763296936686.png", avatarAlt: 'Arjun Mehta professional headshot' },
{ id: '#ORD-78920', customer: 'Sarah Mitchell', product: 'Complete Python & ML Bootcamp', amount: 79, status: 'Processing', date: '2026-05-11', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_14723756c-1763300179179.png", avatarAlt: 'Sarah Mitchell professional headshot' },
{ id: '#ORD-78919', customer: 'Diego Fernández', product: 'Figma Master UI Kit 2026', amount: 49, status: 'Completed', date: '2026-05-10', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_179ebd6f2-1763294255544.png", avatarAlt: 'Diego Fernández professional headshot' },
{ id: '#ORD-78918', customer: 'Yuki Tanaka', product: 'Adobe Photoshop 2026 License', amount: 239, status: 'Completed', date: '2026-05-10', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_10d60e496-1763295319842.png", avatarAlt: 'Yuki Tanaka professional headshot' },
{ id: '#ORD-78917', customer: 'Amara Okonkwo', product: 'Digital Marketing Masterclass', amount: 99, status: 'Refunded', date: '2026-05-10', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_14723756c-1763300179179.png", avatarAlt: 'Amara Okonkwo professional headshot' },
{ id: '#ORD-78916', customer: 'Wei Zhang', product: 'Brand Identity Design Course', amount: 59, status: 'Processing', date: '2026-05-09', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1e5f5dfa8-1763292069790.png", avatarAlt: 'Wei Zhang professional headshot' },
{ id: '#ORD-78915', customer: 'Priya Nair', product: 'Tailwind CSS Component Library', amount: 69, status: 'Completed', date: '2026-05-09', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_18d89f49b-1763301927007.png", avatarAlt: 'Priya Nair professional headshot' }];


const TOP_PRODUCTS = [
{ rank: 1, name: 'Adobe Photoshop 2026 License', sales: 41200, revenue: '$9.8M', growth: '+12%', category: 'Software', positive: true },
{ rank: 2, name: 'Complete Python & ML Bootcamp', sales: 32100, revenue: '$2.5M', growth: '+28%', category: 'Courses', positive: true },
{ rank: 3, name: 'React Next.js 15 Starter Kit', sales: 22700, revenue: '$2.0M', growth: '+45%', category: 'Templates', positive: true },
{ rank: 4, name: 'Figma Master UI Kit 2026', sales: 18400, revenue: '$902K', growth: '+18%', category: 'Templates', positive: true },
{ rank: 5, name: 'Digital Marketing Masterclass', sales: 19800, revenue: '$1.9M', growth: '+33%', category: 'Courses', positive: true }];


const ALL_USERS = [
{ id: 'USR-001', name: 'Arjun Mehta', email: 'arjun.mehta@techflow.com', role: 'Buyer', joined: '2025-03-12', orders: 14, spent: '$1,240', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1d4884314-1763296936686.png", avatarAlt: 'Arjun Mehta profile photo' },
{ id: 'USR-002', name: 'Sarah Mitchell', email: 'sarah.m@pixeldraft.io', role: 'Seller', joined: '2024-11-05', orders: 0, spent: '$0', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_115b700a9-1763294224785.png", avatarAlt: 'Sarah Mitchell profile photo' },
{ id: 'USR-003', name: 'Diego Fernández', email: 'diego.f@globaledge.com', role: 'B2B Buyer', joined: '2025-01-18', orders: 47, spent: '$12,450', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1c09237ab-1763296820723.png", avatarAlt: 'Diego Fernández profile photo' },
{ id: 'USR-004', name: 'Yuki Tanaka', email: 'yuki.t@designstudio.jp', role: 'Seller', joined: '2024-08-22', orders: 0, spent: '$0', status: 'Suspended', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1886efc0a-1763299917516.png", avatarAlt: 'Yuki Tanaka profile photo' },
{ id: 'USR-005', name: 'Amara Okonkwo', email: 'amara.o@wealthmind.ng', role: 'Buyer', joined: '2025-04-03', orders: 6, spent: '$340', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_103b528db-1763293982935.png", avatarAlt: 'Amara Okonkwo profile photo' },
{ id: 'USR-006', name: 'Wei Zhang', email: 'wei.zhang@codetools.cn', role: 'Seller', joined: '2024-06-14', orders: 0, spent: '$0', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1b76d09ba-1763296280585.png", avatarAlt: 'Wei Zhang profile photo' },
{ id: 'USR-007', name: 'Priya Nair', email: 'priya.nair@uicomponents.dev', role: 'Seller', joined: '2024-09-30', orders: 0, spent: '$0', status: 'Active', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1ee2bcef3-1763301295581.png", avatarAlt: 'Priya Nair profile photo' },
{ id: 'USR-008', name: 'Luca Bianchi', email: 'luca.b@motionlab.it', role: 'Seller', joined: '2025-02-08', orders: 0, spent: '$0', status: 'Pending', avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1a84db55c-1763293803948.png", avatarAlt: 'Luca Bianchi profile photo' }];


const COUPONS = [
{ id: 'CPN-001', code: 'LAUNCH50', type: 'Percentage', value: '50%', used: 1240, limit: 5000, expires: '2026-06-30', status: 'Active', minOrder: '$20' },
{ id: 'CPN-002', code: 'DEVTOOLS20', type: 'Percentage', value: '20%', used: 3420, limit: 10000, expires: '2026-12-31', status: 'Active', minOrder: '$50' },
{ id: 'CPN-003', code: 'SAVE15FLAT', type: 'Fixed', value: '$15', used: 890, limit: 2000, expires: '2026-05-31', status: 'Active', minOrder: '$30' },
{ id: 'CPN-004', code: 'ENTERPRISE30', type: 'Percentage', value: '30%', used: 245, limit: 500, expires: '2026-07-15', status: 'Active', minOrder: '$200' },
{ id: 'CPN-005', code: 'SUMMER2025', type: 'Percentage', value: '25%', used: 5000, limit: 5000, expires: '2025-09-01', status: 'Expired', minOrder: '$10' },
{ id: 'CPN-006', code: 'NEWUSER10', type: 'Percentage', value: '10%', used: 8900, limit: 0, expires: 'No Expiry', status: 'Active', minOrder: '$0' }];


const INVENTORY_PRODUCTS = [
{ id: 'PRD-001', name: 'Figma Master UI Kit 2026', category: 'Templates', price: 49, sales: 18400, stock: 'Unlimited', status: 'Published', rating: 4.9, seller: 'DesignLab Studio' },
{ id: 'PRD-002', name: 'Complete Python & ML Bootcamp', category: 'Courses', price: 79, sales: 32100, stock: 'Unlimited', status: 'Published', rating: 4.8, seller: 'CodeAcademy Pro' },
{ id: 'PRD-003', name: 'Adobe Photoshop 2026 License', category: 'Software', price: 239, sales: 41200, stock: '1,240 keys', status: 'Published', rating: 4.7, seller: 'Adobe Official' },
{ id: 'PRD-004', name: 'Epic Stock Music Bundle Vol.3', category: 'Music & Media', price: 29, sales: 7800, stock: 'Unlimited', status: 'Published', rating: 4.6, seller: 'SoundForge Media' },
{ id: 'PRD-005', name: 'The Startup Playbook 2026', category: 'E-Books', price: 19, sales: 4300, stock: 'Unlimited', status: 'Draft', rating: 4.8, seller: 'BizBook Publishers' },
{ id: 'PRD-006', name: 'React Next.js 15 Starter Kit', category: 'Templates', price: 89, sales: 22700, stock: 'Unlimited', status: 'Published', rating: 4.9, seller: 'DevBoilerplate' }];


const NAV_ITEMS = [
{ id: 'overview', label: 'Overview', icon: 'HomeIcon' },
{ id: 'products', label: 'Products', icon: 'CubeIcon' },
{ id: 'orders', label: 'Orders', icon: 'ShoppingBagIcon' },
{ id: 'users', label: 'Users', icon: 'UsersIcon' },
{ id: 'sellers', label: 'Sellers', icon: 'BuildingStorefrontIcon' },
{ id: 'analytics', label: 'Analytics', icon: 'ChartBarIcon' },
{ id: 'coupons', label: 'Coupons', icon: 'TagIcon' },
{ id: 'settings', label: 'Settings', icon: 'Cog6ToothIcon' }];


const KPI_CARDS = [
{ label: 'Total Revenue', value: '$4.18M', change: '+24.3%', positive: true, icon: 'CurrencyDollarIcon', color: 'from-primary to-accent', sub: 'This year' },
{ label: 'Total Orders', value: '71,420', change: '+18.7%', positive: true, icon: 'ShoppingBagIcon', color: 'from-secondary to-purple-400', sub: 'This year' },
{ label: 'Active Users', value: '2.04M', change: '+31.2%', positive: true, icon: 'UsersIcon', color: 'from-accent to-yellow-400', sub: 'Registered' },
{ label: 'Active Products', value: '512,840', change: '+8.4%', positive: true, icon: 'CubeIcon', color: 'from-green-500 to-emerald-400', sub: 'Listed' }];


type AdminTab = 'overview' | 'products' | 'orders' | 'users' | 'sellers' | 'analytics' | 'coupons' | 'settings';

function StatusBadge({ status }: {status: string;}) {
  const styles: Record<string, string> = {
    Completed: 'bg-green-50 text-green-700 border-green-200',
    Processing: 'bg-blue-50 text-blue-700 border-blue-200',
    Refunded: 'bg-red-50 text-red-700 border-red-200',
    Cancelled: 'bg-gray-50 text-gray-600 border-gray-200',
    Active: 'bg-green-50 text-green-700 border-green-200',
    Suspended: 'bg-red-50 text-red-700 border-red-200',
    Pending: 'bg-yellow-50 text-yellow-700 border-yellow-200',
    Published: 'bg-green-50 text-green-700 border-green-200',
    Draft: 'bg-gray-50 text-gray-600 border-gray-200',
    Expired: 'bg-red-50 text-red-700 border-red-200'
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-600 border ${styles[status] || 'bg-gray-50 text-gray-600 border-gray-200'}`}>
      {status}
    </span>);

}

function RoleBadge({ role }: {role: string;}) {
  const styles: Record<string, string> = {
    'Buyer': 'bg-blue-50 text-blue-700 border-blue-200',
    'Seller': 'bg-purple-50 text-purple-700 border-purple-200',
    'B2B Buyer': 'bg-orange-50 text-orange-700 border-orange-200',
    'Admin': 'bg-red-50 text-red-700 border-red-200'
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-600 border ${styles[role] || 'bg-gray-50 text-gray-600 border-gray-200'}`}>
      {role}
    </span>);

}

export default function AdminDashboardClient() {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [chartType, setChartType] = useState<'revenue' | 'orders' | 'users'>('revenue');
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCouponModal, setShowCouponModal] = useState(false);

  const filteredUsers = ALL_USERS.filter(
    (u) =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-muted overflow-hidden font-sans">
      {/* Mobile Sidebar Overlay */}
      {mobileSidebarOpen &&
      <div
        className="fixed inset-0 z-40 bg-foreground/30 backdrop-blur-sm lg:hidden"
        onClick={() => setMobileSidebarOpen(false)} />

      }

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:relative z-50 lg:z-auto
          h-full flex flex-col bg-card border-r border-border
          transition-all duration-300 ease-in-out
          ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          ${sidebarCollapsed ? 'w-16' : 'w-60'}
        `}>
        
        {/* Sidebar Header */}
        <div className={`flex items-center border-b border-border h-16 flex-shrink-0 ${sidebarCollapsed ? 'justify-center px-2' : 'justify-between px-4'}`}>
          {!sidebarCollapsed &&
          <div className="flex items-center gap-2">
              <AppLogo size={32} />
              <span className="font-extrabold text-base text-foreground">DigiMart</span>
            </div>
          }
          {sidebarCollapsed && <AppLogo size={32} />}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="hidden lg:flex p-1.5 rounded-lg hover:bg-muted text-muted-foreground transition-colors"
            aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
            
            <Icon name={sidebarCollapsed ? 'ChevronRightIcon' : 'ChevronLeftIcon'} size={16} />
          </button>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-0.5">
          {NAV_ITEMS.map((item) =>
          <button
            key={item.id}
            onClick={() => {setActiveTab(item.id as AdminTab);setMobileSidebarOpen(false);}}
            className={`sidebar-link w-full ${activeTab === item.id ? 'active' : ''} ${sidebarCollapsed ? 'justify-center !px-2' : ''}`}
            title={sidebarCollapsed ? item.label : undefined}>
            
              <Icon name={item.icon as 'HomeIcon'} size={20} className={activeTab === item.id ? 'text-primary' : 'text-muted-foreground'} />
              {!sidebarCollapsed && <span>{item.label}</span>}
              {!sidebarCollapsed && item.id === 'orders' &&
            <span className="ml-auto bg-primary text-primary-foreground text-xs font-700 px-1.5 py-0.5 rounded-full">7</span>
            }
            </button>
          )}
        </nav>

        {/* Sidebar Footer */}
        {!sidebarCollapsed &&
        <div className="p-4 border-t border-border flex-shrink-0">
            <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted transition-colors cursor-pointer">
              <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_1ead2f84b-1763301713641.png"
                alt="Admin user profile photo"
                width={32}
                height={32}
                className="object-cover w-full h-full" />
              
              </div>
              <div className="min-w-0">
                <div className="text-sm font-700 text-foreground truncate">Admin User</div>
                <div className="text-xs text-muted-foreground truncate">admin@digimart.com</div>
              </div>
              <Icon name="EllipsisVerticalIcon" size={16} className="text-muted-foreground flex-shrink-0" />
            </div>
          </div>
        }
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-card border-b border-border flex items-center justify-between px-4 sm:px-6 flex-shrink-0 z-30">
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-muted text-muted-foreground"
              onClick={() => setMobileSidebarOpen(true)}
              aria-label="Open sidebar menu">
              
              <Icon name="Bars3Icon" size={22} />
            </button>
            <div>
              <h1 className="text-lg font-800 text-foreground capitalize">
                {activeTab === 'overview' ? 'Dashboard Overview' : activeTab}
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                {new Date('2026-05-11').toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search */}
            <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-lg bg-muted border border-border text-sm text-muted-foreground w-56">
              <Icon name="MagnifyingGlassIcon" size={16} />
              <input
                type="text"
                placeholder="Search anything…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent outline-none text-foreground placeholder:text-muted-foreground w-full text-sm" />
              
            </div>

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="relative p-2.5 rounded-xl hover:bg-muted text-muted-foreground transition-colors"
                aria-label="Notifications">
                
                <Icon name="BellIcon" size={20} />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-primary rounded-full" />
              </button>
              {notifOpen &&
              <div className="absolute right-0 top-12 w-80 bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden">
                  <div className="p-4 border-b border-border flex items-center justify-between">
                    <span className="font-700 text-foreground">Notifications</span>
                    <span className="text-xs text-primary font-600 cursor-pointer">Mark all read</span>
                  </div>
                  {[
                { icon: 'ShoppingBagIcon', text: 'New order #ORD-78921 received', time: '2 min ago', color: 'text-primary' },
                { icon: 'UsersIcon', text: 'New seller registration: Luca Bianchi', time: '18 min ago', color: 'text-secondary' },
                { icon: 'ExclamationTriangleIcon', text: 'Low license stock: Photoshop 2026', time: '1 hr ago', color: 'text-accent' },
                { icon: 'CurrencyDollarIcon', text: 'Payout processed: $124,500', time: '3 hr ago', color: 'text-green-600' }].
                map((n, i) =>
                <div key={i} className="flex items-start gap-3 px-4 py-3 hover:bg-muted transition-colors cursor-pointer border-b border-border/50 last:border-0">
                      <div className={`w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 mt-0.5`}>
                        <Icon name={n.icon as 'BellIcon'} size={16} className={n.color} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-500 text-foreground leading-snug">{n.text}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{n.time}</p>
                      </div>
                    </div>
                )}
                </div>
              }
            </div>

            {/* Admin Avatar */}
            <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-primary/30 cursor-pointer">
              <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_155932999-1763301836922.png"
                alt="Admin profile photo"
                width={36}
                height={36}
                className="object-cover w-full h-full" />
              
            </div>

            {/* Back to site */}
            <Link
              href="/"
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-xs font-600 text-muted-foreground hover:text-foreground hover:border-primary/40 transition-all">
              
              <Icon name="ArrowTopRightOnSquareIcon" size={14} />
              View Site
            </Link>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">

          {/* ── OVERVIEW TAB ── */}
          {activeTab === 'overview' &&
          <div className="space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                {KPI_CARDS.map((kpi) =>
              <div key={kpi.label} className="bg-card rounded-2xl border border-border p-5 hover:shadow-lg hover:shadow-black/5 transition-all">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${kpi.color} flex items-center justify-center`}>
                        <Icon name={kpi.icon as 'CurrencyDollarIcon'} size={22} className="text-white" />
                      </div>
                      <span className={`flex items-center gap-1 text-xs font-700 px-2 py-1 rounded-full ${kpi.positive ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                        <Icon name={kpi.positive ? 'ArrowTrendingUpIcon' : 'ArrowTrendingDownIcon'} size={12} />
                        {kpi.change}
                      </span>
                    </div>
                    <div className="text-2xl font-extrabold text-foreground tabular-nums">{kpi.value}</div>
                    <div className="text-sm text-muted-foreground font-500 mt-1">{kpi.label}</div>
                    <div className="text-xs text-muted-foreground/70 mt-0.5">{kpi.sub}</div>
                  </div>
              )}
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                {/* Revenue Chart */}
                <div className="xl:col-span-2 bg-card rounded-2xl border border-border p-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                    <div>
                      <h3 className="font-800 text-foreground text-base">Revenue & Growth</h3>
                      <p className="text-sm text-muted-foreground">Full year 2026 performance</p>
                    </div>
                    <div className="flex gap-1 bg-muted rounded-xl p-1">
                      {(['revenue', 'orders', 'users'] as const).map((t) =>
                    <button
                      key={t}
                      onClick={() => setChartType(t)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-600 capitalize transition-all ${
                      chartType === t ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`
                      }>
                      
                          {t}
                        </button>
                    )}
                    </div>
                  </div>
                  <ResponsiveContainer width="100%" height={240}>
                    <AreaChart data={SALES_DATA} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#FF3D57" stopOpacity={0.2} />
                          <stop offset="95%" stopColor="#FF3D57" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                      <YAxis
                      tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v) =>
                      chartType === 'revenue' ?
                      `$${(v / 1000).toFixed(0)}K` :
                      v >= 1000 ?
                      `${(v / 1000).toFixed(1)}K` :
                      String(v)
                      } />
                    
                      <Tooltip
                      contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', fontSize: '12px' }}
                      formatter={(value: number) =>
                      chartType === 'revenue' ?
                      [`$${value.toLocaleString()}`, 'Revenue'] :
                      [value.toLocaleString(), chartType === 'orders' ? 'Orders' : 'New Users']
                      } />
                    
                      <Area
                      type="monotone"
                      dataKey={chartType}
                      stroke="#FF3D57"
                      strokeWidth={2.5}
                      fill="url(#colorGradient)"
                      dot={false}
                      activeDot={{ r: 5, fill: '#FF3D57' }} />
                    
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Category Breakdown */}
                <div className="bg-card rounded-2xl border border-border p-5">
                  <h3 className="font-800 text-foreground text-base mb-1">Sales by Category</h3>
                  <p className="text-sm text-muted-foreground mb-5">Revenue distribution</p>
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={CATEGORY_DATA} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                      <XAxis type="number" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                      <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} width={65} />
                      <Tooltip
                      contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', fontSize: '12px' }}
                      formatter={(v: number) => [`${v}%`, 'Share']} />
                    
                      <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                        {CATEGORY_DATA.map((entry, index) =>
                      <rect key={`cell-${index}`} fill={entry.fill} />
                      )}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {CATEGORY_DATA.map((c) =>
                  <div key={c.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: c.fill }} />
                          <span className="text-muted-foreground font-500">{c.name}</span>
                        </div>
                        <span className="font-700 text-foreground">{c.value}%</span>
                      </div>
                  )}
                  </div>
                </div>
              </div>

              {/* Bottom Row: Recent Orders + Top Products */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                {/* Recent Orders */}
                <div className="xl:col-span-2 bg-card rounded-2xl border border-border overflow-hidden">
                  <div className="flex items-center justify-between p-5 border-b border-border">
                    <div>
                      <h3 className="font-800 text-foreground text-base">Recent Orders</h3>
                      <p className="text-sm text-muted-foreground">Latest 7 transactions</p>
                    </div>
                    <button
                    onClick={() => setActiveTab('orders')}
                    className="text-sm font-600 text-primary hover:underline flex items-center gap-1">
                    
                      View all <Icon name="ArrowRightIcon" size={14} />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-muted/50">
                          <th className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-5 py-3">Order</th>
                          <th className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-3 py-3 hidden sm:table-cell">Customer</th>
                          <th className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-3 py-3 hidden md:table-cell">Product</th>
                          <th className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-3 py-3">Amount</th>
                          <th className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-3 py-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {RECENT_ORDERS.map((order) =>
                      <tr key={order.id} className="hover:bg-muted/30 transition-colors">
                            <td className="px-5 py-3.5">
                              <span className="text-sm font-600 text-primary">{order.id}</span>
                              <div className="text-xs text-muted-foreground mt-0.5">{order.date}</div>
                            </td>
                            <td className="px-3 py-3.5 hidden sm:table-cell">
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-full overflow-hidden flex-shrink-0">
                                  <AppImage src={order.avatar} alt={order.avatarAlt} width={28} height={28} className="object-cover w-full h-full" />
                                </div>
                                <span className="text-sm font-500 text-foreground whitespace-nowrap">{order.customer}</span>
                              </div>
                            </td>
                            <td className="px-3 py-3.5 hidden md:table-cell">
                              <span className="text-sm text-muted-foreground line-clamp-1 max-w-[160px]">{order.product}</span>
                            </td>
                            <td className="px-3 py-3.5">
                              <span className="text-sm font-700 text-foreground">${order.amount}</span>
                            </td>
                            <td className="px-3 py-3.5">
                              <StatusBadge status={order.status} />
                            </td>
                          </tr>
                      )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Top Products */}
                <div className="bg-card rounded-2xl border border-border overflow-hidden">
                  <div className="flex items-center justify-between p-5 border-b border-border">
                    <div>
                      <h3 className="font-800 text-foreground text-base">Top Products</h3>
                      <p className="text-sm text-muted-foreground">By revenue 2026</p>
                    </div>
                    <button
                    onClick={() => setActiveTab('products')}
                    className="text-sm font-600 text-primary hover:underline flex items-center gap-1">
                    
                      All <Icon name="ArrowRightIcon" size={14} />
                    </button>
                  </div>
                  <div className="divide-y divide-border">
                    {TOP_PRODUCTS.map((p) =>
                  <div key={p.rank} className="flex items-center gap-3 px-5 py-3.5 hover:bg-muted/30 transition-colors">
                        <span className="text-lg font-900 text-muted-foreground/40 w-6 text-center tabular-nums">{p.rank}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-600 text-foreground line-clamp-1">{p.name}</div>
                          <div className="text-xs text-muted-foreground mt-0.5">{p.sales.toLocaleString()} sales</div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-sm font-700 text-foreground">{p.revenue}</div>
                          <div className="text-xs text-green-600 font-600">{p.growth}</div>
                        </div>
                      </div>
                  )}
                  </div>
                </div>
              </div>
            </div>
          }

          {/* ── PRODUCTS TAB ── */}
          {activeTab === 'products' &&
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-800 text-foreground">Product Management</h2>
                  <p className="text-sm text-muted-foreground">Manage all digital products in your marketplace</p>
                </div>
                <button className="btn-primary gap-2 !py-2.5 !px-5 !text-sm w-fit">
                  <Icon name="PlusIcon" size={18} />
                  Add Product
                </button>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
              { label: 'Total Products', value: '512,840', icon: 'CubeIcon', color: 'text-primary' },
              { label: 'Published', value: '498,210', icon: 'CheckCircleIcon', color: 'text-green-600' },
              { label: 'Draft', value: '14,630', icon: 'PencilSquareIcon', color: 'text-yellow-600' },
              { label: 'Low Stock', value: '23', icon: 'ExclamationTriangleIcon', color: 'text-red-600' }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-xl border border-border p-4">
                    <Icon name={s.icon as 'CubeIcon'} size={20} className={s.color} />
                    <div className="text-xl font-800 text-foreground mt-2">{s.value}</div>
                    <div className="text-xs text-muted-foreground font-500 mt-0.5">{s.label}</div>
                  </div>
              )}
              </div>

              {/* Products Table */}
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="p-5 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <h3 className="font-700 text-foreground">All Products</h3>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted border border-border text-sm text-muted-foreground">
                      <Icon name="MagnifyingGlassIcon" size={15} />
                      <input placeholder="Search products…" className="bg-transparent outline-none text-foreground text-sm w-36 sm:w-48" />
                    </div>
                    <select className="px-3 py-2 rounded-lg border border-border bg-card text-sm font-500 text-foreground focus:outline-none focus:border-primary">
                      <option>All Categories</option>
                      <option>Software</option>
                      <option>Courses</option>
                      <option>Templates</option>
                    </select>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/50">
                        {['Product', 'Category', 'Price', 'Sales', 'Rating', 'Status', 'Actions'].map((h) =>
                      <th key={h} className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-5 py-3 whitespace-nowrap">{h}</th>
                      )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {INVENTORY_PRODUCTS.map((p) =>
                    <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4">
                            <div className="font-600 text-foreground text-sm line-clamp-1 max-w-[200px]">{p.name}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">{p.seller}</div>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-xs font-600 bg-muted text-muted-foreground px-2 py-1 rounded-full">{p.category}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="font-700 text-foreground text-sm">${p.price}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground font-500">{p.sales.toLocaleString()}</span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1">
                              <Icon name="StarIcon" size={13} className="text-yellow-400" variant="solid" />
                              <span className="text-sm font-600 text-foreground">{p.rating}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <StatusBadge status={p.status} />
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition-colors" aria-label={`Edit ${p.name}`}>
                                <Icon name="PencilSquareIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-red-600 transition-colors" aria-label={`Delete ${p.name}`}>
                                <Icon name="TrashIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" aria-label={`More options for ${p.name}`}>
                                <Icon name="EllipsisVerticalIcon" size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                    )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          }

          {/* ── ORDERS TAB ── */}
          {activeTab === 'orders' &&
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-800 text-foreground">Orders & Payments</h2>
                  <p className="text-sm text-muted-foreground">Track and manage all transactions</p>
                </div>
                <button className="btn-primary gap-2 !py-2.5 !px-5 !text-sm w-fit">
                  <Icon name="ArrowDownTrayIcon" size={18} />
                  Export CSV
                </button>
              </div>

              {/* Order Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
              { label: 'Total Orders', value: '71,420', change: '+18.7%', icon: 'ShoppingBagIcon', color: 'text-primary' },
              { label: 'Completed', value: '68,210', change: '95.5%', icon: 'CheckCircleIcon', color: 'text-green-600' },
              { label: 'Processing', value: '2,840', change: '4.0%', icon: 'ClockIcon', color: 'text-blue-600' },
              { label: 'Refunded', value: '370', change: '0.5%', icon: 'ArrowUturnLeftIcon', color: 'text-red-600' }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-xl border border-border p-4">
                    <Icon name={s.icon as 'ShoppingBagIcon'} size={20} className={s.color} />
                    <div className="text-xl font-800 text-foreground mt-2">{s.value}</div>
                    <div className="text-xs text-muted-foreground font-500 mt-0.5">{s.label}</div>
                    <div className="text-xs text-green-600 font-600 mt-1">{s.change}</div>
                  </div>
              )}
              </div>

              {/* Orders Table */}
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="p-5 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <h3 className="font-700 text-foreground">All Orders</h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    {['All', 'Completed', 'Processing', 'Refunded'].map((s) =>
                  <button key={s} className="px-3 py-1.5 rounded-full text-xs font-600 border border-border hover:border-primary hover:text-primary transition-all text-muted-foreground">
                        {s}
                      </button>
                  )}
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/50">
                        {['Order ID', 'Customer', 'Product', 'Amount', 'Date', 'Status', 'Actions'].map((h) =>
                      <th key={h} className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-5 py-3 whitespace-nowrap">{h}</th>
                      )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {RECENT_ORDERS.map((order) =>
                    <tr key={order.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4">
                            <span className="text-sm font-700 text-primary">{order.id}</span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-full overflow-hidden flex-shrink-0">
                                <AppImage src={order.avatar} alt={order.avatarAlt} width={28} height={28} className="object-cover w-full h-full" />
                              </div>
                              <span className="text-sm font-500 text-foreground whitespace-nowrap">{order.customer}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground line-clamp-1 max-w-[180px]">{order.product}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="font-700 text-foreground text-sm">${order.amount}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground">{order.date}</span>
                          </td>
                          <td className="px-5 py-4">
                            <StatusBadge status={order.status} />
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition-colors" aria-label={`View order ${order.id}`}>
                                <Icon name="EyeIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" aria-label={`Download invoice for ${order.id}`}>
                                <Icon name="ArrowDownTrayIcon" size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                    )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          }

          {/* ── USERS TAB ── */}
          {activeTab === 'users' &&
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-800 text-foreground">User Management</h2>
                  <p className="text-sm text-muted-foreground">Manage buyers, sellers and enterprise accounts</p>
                </div>
                <button className="btn-primary gap-2 !py-2.5 !px-5 !text-sm w-fit">
                  <Icon name="PlusIcon" size={18} />
                  Add User
                </button>
              </div>

              {/* User Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
              { label: 'Total Users', value: '2.04M', icon: 'UsersIcon', color: 'text-primary' },
              { label: 'Buyers', value: '1.98M', icon: 'ShoppingBagIcon', color: 'text-blue-600' },
              { label: 'Sellers', value: '14,230', icon: 'BuildingStorefrontIcon', color: 'text-secondary' },
              { label: 'Suspended', value: '1,240', icon: 'NoSymbolIcon', color: 'text-red-600' }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-xl border border-border p-4">
                    <Icon name={s.icon as 'UsersIcon'} size={20} className={s.color} />
                    <div className="text-xl font-800 text-foreground mt-2">{s.value}</div>
                    <div className="text-xs text-muted-foreground font-500 mt-0.5">{s.label}</div>
                  </div>
              )}
              </div>

              {/* Search */}
              <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-2.5 max-w-sm">
                <Icon name="MagnifyingGlassIcon" size={18} className="text-muted-foreground flex-shrink-0" />
                <input
                type="text"
                placeholder="Search users by name or email…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent outline-none text-foreground text-sm w-full placeholder:text-muted-foreground" />
              
              </div>

              {/* Users Table */}
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/50">
                        {['User', 'Email', 'Role', 'Joined', 'Orders', 'Total Spent', 'Status', 'Actions'].map((h) =>
                      <th key={h} className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-5 py-3 whitespace-nowrap">{h}</th>
                      )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredUsers.map((user) =>
                    <tr key={user.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0">
                                <AppImage src={user.avatar} alt={user.avatarAlt} width={36} height={36} className="object-cover w-full h-full" />
                              </div>
                              <div>
                                <div className="text-sm font-700 text-foreground whitespace-nowrap">{user.name}</div>
                                <div className="text-xs text-muted-foreground">{user.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground">{user.email}</span>
                          </td>
                          <td className="px-5 py-4">
                            <RoleBadge role={user.role} />
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground whitespace-nowrap">{user.joined}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm font-600 text-foreground">{user.orders}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm font-700 text-foreground">{user.spent}</span>
                          </td>
                          <td className="px-5 py-4">
                            <StatusBadge status={user.status} />
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition-colors" aria-label={`View ${user.name}`}>
                                <Icon name="EyeIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" aria-label={`Edit ${user.name}`}>
                                <Icon name="PencilSquareIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-red-600 transition-colors" aria-label={`Suspend ${user.name}`}>
                                <Icon name="NoSymbolIcon" size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                    )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          }

          {/* ── SELLERS TAB ── */}
          {activeTab === 'sellers' &&
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-800 text-foreground">Seller Management</h2>
                  <p className="text-sm text-muted-foreground">Manage and verify sellers on the marketplace</p>
                </div>
                <button className="btn-primary gap-2 !py-2.5 !px-5 !text-sm w-fit">
                  <Icon name="EnvelopeIcon" size={18} />
                  Invite Seller
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
              { label: 'Active Sellers', value: '14,230', change: '+8.2%', icon: 'BuildingStorefrontIcon', bg: 'from-primary to-accent' },
              { label: 'Pending Verification', value: '342', change: 'Needs review', icon: 'ClockIcon', bg: 'from-yellow-500 to-orange-400' },
              { label: 'Total Seller Payouts', value: '$4.2M', change: 'This month', icon: 'BanknotesIcon', bg: 'from-secondary to-purple-400' }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-2xl border border-border p-5 flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.bg} flex items-center justify-center flex-shrink-0`}>
                      <Icon name={s.icon as 'BuildingStorefrontIcon'} size={28} className="text-white" />
                    </div>
                    <div>
                      <div className="text-2xl font-extrabold text-foreground">{s.value}</div>
                      <div className="text-sm text-muted-foreground font-500">{s.label}</div>
                      <div className="text-xs text-green-600 font-600 mt-0.5">{s.change}</div>
                    </div>
                  </div>
              )}
              </div>

              {/* Sellers from users list filtered */}
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="p-5 border-b border-border">
                  <h3 className="font-700 text-foreground">Recent Sellers</h3>
                </div>
                <div className="divide-y divide-border">
                  {ALL_USERS.filter((u) => u.role === 'Seller').map((seller) =>
                <div key={seller.id} className="flex items-center gap-4 px-5 py-4 hover:bg-muted/30 transition-colors">
                      <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                        <AppImage src={seller.avatar} alt={seller.avatarAlt} width={40} height={40} className="object-cover w-full h-full" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-700 text-foreground text-sm">{seller.name}</div>
                        <div className="text-xs text-muted-foreground">{seller.email}</div>
                      </div>
                      <div className="text-xs text-muted-foreground hidden md:block">Joined {seller.joined}</div>
                      <StatusBadge status={seller.status} />
                      <div className="flex items-center gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition-colors" aria-label={`View seller ${seller.name}`}>
                          <Icon name="EyeIcon" size={16} />
                        </button>
                        {seller.status === 'Pending' &&
                    <button className="px-3 py-1.5 rounded-lg bg-green-50 text-green-700 border border-green-200 text-xs font-600 hover:bg-green-100 transition-colors">
                            Approve
                          </button>
                    }
                      </div>
                    </div>
                )}
                </div>
              </div>
            </div>
          }

          {/* ── ANALYTICS TAB ── */}
          {activeTab === 'analytics' &&
          <div className="space-y-6">
              <div>
                <h2 className="text-xl font-800 text-foreground">Analytics & Reports</h2>
                <p className="text-sm text-muted-foreground">Deep insights into marketplace performance</p>
              </div>

              {/* Summary KPIs */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
              { label: 'Avg Order Value', value: '$58.50', change: '+6.2%', positive: true },
              { label: 'Conversion Rate', value: '3.84%', change: '+0.4%', positive: true },
              { label: 'Cart Abandonment', value: '62.1%', change: '-3.2%', positive: true },
              { label: 'Repeat Purchase', value: '41.8%', change: '+5.1%', positive: true }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-xl border border-border p-4">
                    <div className="text-2xl font-800 text-foreground">{s.value}</div>
                    <div className="text-sm text-muted-foreground font-500 mt-1">{s.label}</div>
                    <div className={`text-xs font-600 mt-1 ${s.positive ? 'text-green-600' : 'text-red-600'}`}>{s.change} vs last month</div>
                  </div>
              )}
              </div>

              {/* Revenue Chart Full */}
              <div className="bg-card rounded-2xl border border-border p-5">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="font-800 text-foreground text-base">Revenue vs Orders — 2026</h3>
                    <p className="text-sm text-muted-foreground">Monthly comparison</p>
                  </div>
                  <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm font-600 text-muted-foreground hover:text-foreground transition-colors">
                    <Icon name="ArrowDownTrayIcon" size={16} />
                    Export
                  </button>
                </div>
                <ResponsiveContainer width="100%" height={320}>
                  <LineChart data={SALES_DATA} margin={{ top: 5, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis yAxisId="left" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}K`} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(1)}K`} />
                    <Tooltip
                    contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', fontSize: '12px' }} />
                  
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '16px' }} />
                    <Line yAxisId="left" type="monotone" dataKey="revenue" stroke="#FF3D57" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} name="Revenue ($)" />
                    <Line yAxisId="right" type="monotone" dataKey="orders" stroke="#7B2FFF" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} name="Orders" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Category Revenue Bars */}
              <div className="bg-card rounded-2xl border border-border p-5">
                <h3 className="font-800 text-foreground text-base mb-1">Revenue by Category</h3>
                <p className="text-sm text-muted-foreground mb-5">Annual breakdown</p>
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={CATEGORY_DATA} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                    <Tooltip
                    contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', fontSize: '12px' }}
                    formatter={(v: number) => [`${v}%`, 'Revenue Share']} />
                  
                    <Bar dataKey="value" radius={[6, 6, 0, 0]} fill="#FF3D57" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          }

          {/* ── COUPONS TAB ── */}
          {activeTab === 'coupons' &&
          <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-800 text-foreground">Discount & Coupon Management</h2>
                  <p className="text-sm text-muted-foreground">Create and manage promotional codes</p>
                </div>
                <button
                onClick={() => setShowCouponModal(true)}
                className="btn-primary gap-2 !py-2.5 !px-5 !text-sm w-fit">
                
                  <Icon name="PlusIcon" size={18} />
                  Create Coupon
                </button>
              </div>

              {/* Coupon Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
              { label: 'Active Coupons', value: '5', icon: 'TagIcon', color: 'text-primary' },
              { label: 'Total Redemptions', value: '19,694', icon: 'CheckBadgeIcon', color: 'text-green-600' },
              { label: 'Revenue Impacted', value: '$284K', icon: 'CurrencyDollarIcon', color: 'text-secondary' },
              { label: 'Avg Discount', value: '24%', icon: 'ReceiptPercentIcon', color: 'text-accent' }].
              map((s) =>
              <div key={s.label} className="bg-card rounded-xl border border-border p-4">
                    <Icon name={s.icon as 'TagIcon'} size={20} className={s.color} />
                    <div className="text-xl font-800 text-foreground mt-2">{s.value}</div>
                    <div className="text-xs text-muted-foreground font-500 mt-0.5">{s.label}</div>
                  </div>
              )}
              </div>

              {/* Coupons Table */}
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="p-5 border-b border-border">
                  <h3 className="font-700 text-foreground">All Coupons</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/50">
                        {['Code', 'Type', 'Value', 'Min Order', 'Used / Limit', 'Expires', 'Status', 'Actions'].map((h) =>
                      <th key={h} className="text-left text-xs font-700 text-muted-foreground uppercase tracking-wider px-5 py-3 whitespace-nowrap">{h}</th>
                      )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {COUPONS.map((coupon) =>
                    <tr key={coupon.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4">
                            <code className="text-sm font-800 text-primary bg-primary/8 px-2.5 py-1 rounded-lg">{coupon.code}</code>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground font-500">{coupon.type}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm font-700 text-foreground">{coupon.value}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground">{coupon.minOrder}</span>
                          </td>
                          <td className="px-5 py-4">
                            <div>
                              <span className="text-sm font-600 text-foreground">{coupon.used.toLocaleString()}</span>
                              {coupon.limit > 0 &&
                          <span className="text-sm text-muted-foreground"> / {coupon.limit.toLocaleString()}</span>
                          }
                              {coupon.limit > 0 &&
                          <div className="mt-1 h-1 w-24 bg-muted rounded-full overflow-hidden">
                                  <div
                              className="h-full bg-primary rounded-full"
                              style={{ width: `${Math.min(coupon.used / coupon.limit * 100, 100)}%` }} />
                            
                                </div>
                          }
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-sm text-muted-foreground whitespace-nowrap">{coupon.expires}</span>
                          </td>
                          <td className="px-5 py-4">
                            <StatusBadge status={coupon.status} />
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-primary transition-colors" aria-label={`Edit coupon ${coupon.code}`}>
                                <Icon name="PencilSquareIcon" size={16} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-red-600 transition-colors" aria-label={`Delete coupon ${coupon.code}`}>
                                <Icon name="TrashIcon" size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                    )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Create Coupon Modal */}
              {showCouponModal &&
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                  <div className="absolute inset-0 bg-foreground/40 backdrop-blur-sm" onClick={() => setShowCouponModal(false)} />
                  <div className="relative bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md p-6 z-10">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-800 text-foreground">Create New Coupon</h3>
                      <button onClick={() => setShowCouponModal(false)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground" aria-label="Close modal">
                        <Icon name="XMarkIcon" size={20} />
                      </button>
                    </div>
                    <form className="space-y-4" onSubmit={(e) => {e.preventDefault();setShowCouponModal(false);}}>
                      <div>
                        <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Coupon Code</label>
                        <input
                      type="text"
                      placeholder="e.g. SAVE20OFF"
                      className="w-full px-4 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm font-600 uppercase placeholder:normal-case placeholder:font-400 focus:outline-none focus:border-primary" />
                    
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Discount Type</label>
                          <select className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary">
                            <option>Percentage</option>
                            <option>Fixed Amount</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Value</label>
                          <input type="text" placeholder="e.g. 20% or $15" className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary" />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Min Order</label>
                          <input type="text" placeholder="$0" className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary" />
                        </div>
                        <div>
                          <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Usage Limit</label>
                          <input type="number" placeholder="Unlimited" className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">Expiry Date</label>
                        <input type="date" className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary" />
                      </div>
                      <div className="flex gap-3 pt-2">
                        <button type="button" onClick={() => setShowCouponModal(false)} className="flex-1 btn-secondary !py-2.5">Cancel</button>
                        <button type="submit" className="flex-1 btn-primary !py-2.5">Create Coupon</button>
                      </div>
                    </form>
                  </div>
                </div>
            }
            </div>
          }

          {/* ── SETTINGS TAB ── */}
          {activeTab === 'settings' &&
          <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-xl font-800 text-foreground">Platform Settings</h2>
                <p className="text-sm text-muted-foreground">Configure marketplace settings and preferences</p>
              </div>

              {[
            {
              title: 'General Settings',
              fields: [
              { label: 'Marketplace Name', value: 'DigiMart', type: 'text' },
              { label: 'Support Email', value: 'support@digimart.com', type: 'email' },
              { label: 'Default Currency', value: 'USD ($)', type: 'text' },
              { label: 'Platform Commission (%)', value: '15', type: 'number' }]

            },
            {
              title: 'Payment Settings',
              fields: [
              { label: 'Payment Gateway', value: 'Stripe + PayPal', type: 'text' },
              { label: 'Payout Schedule', value: 'Weekly', type: 'text' },
              { label: 'Min Payout Amount ($)', value: '50', type: 'number' }]

            }].
            map((section) =>
            <div key={section.title} className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-700 text-foreground text-base mb-5">{section.title}</h3>
                  <div className="space-y-4">
                    {section.fields.map((field) =>
                <div key={field.label}>
                        <label className="block text-xs font-700 text-foreground uppercase tracking-wider mb-1.5">{field.label}</label>
                        <input
                    type={field.type}
                    defaultValue={field.value}
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:border-primary transition-colors" />
                  
                      </div>
                )}
                  </div>
                  <div className="mt-5 flex justify-end">
                    <button className="btn-primary !py-2.5 !px-6 !text-sm gap-2">
                      <Icon name="CheckIcon" size={16} />
                      Save Changes
                    </button>
                  </div>
                </div>
            )}

              {/* Toggles */}
              <div className="bg-card rounded-2xl border border-border p-6">
                <h3 className="font-700 text-foreground text-base mb-5">Feature Flags</h3>
                <div className="space-y-4">
                  {[
                { label: 'Seller Verification Required', desc: 'New sellers must be verified before listing', enabled: true },
                { label: 'B2B Bulk Pricing', desc: 'Enable volume discounts for enterprise buyers', enabled: true },
                { label: 'Guest Checkout', desc: 'Allow purchases without account creation', enabled: false },
                { label: 'Digital DRM Protection', desc: 'Enforce license validation on all downloads', enabled: true }].
                map((toggle) =>
                <div key={toggle.label} className="flex items-center justify-between gap-4 py-1">
                      <div>
                        <div className="text-sm font-600 text-foreground">{toggle.label}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{toggle.desc}</div>
                      </div>
                      <button
                    className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${toggle.enabled ? 'bg-primary' : 'bg-border'}`}
                    aria-label={`Toggle ${toggle.label}`}
                    aria-pressed={toggle.enabled}>
                    
                        <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${toggle.enabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
                      </button>
                    </div>
                )}
                </div>
              </div>
            </div>
          }
        </main>
      </div>
    </div>);

}