'use client';
import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const SELLER_BENEFITS = [
{ icon: 'CurrencyDollarIcon', title: 'Earn up to 85% Revenue Share', desc: 'Industry-leading payout on every sale, with weekly automated transfers.' },
{ icon: 'GlobeAltIcon', title: 'Reach 2M+ Global Buyers', desc: 'Your products visible to customers across 120+ countries from day one.' },
{ icon: 'ChartBarIcon', title: 'Advanced Analytics Dashboard', desc: 'Real-time sales data, buyer insights, and conversion optimization tools.' },
{ icon: 'ShieldCheckIcon', title: 'Secure DRM & License Management', desc: 'Enterprise-grade protection for your digital assets and licenses.' }];


const SELLER_STATS = [
{ value: '$4.2M', label: 'Paid to sellers last month' },
{ value: '14K+', label: 'Active sellers globally' },
{ value: '85%', label: 'Max revenue share' }];


export default function SellerCTASection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll('.reveal').forEach((el) => el.classList.add('active'));
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-20 px-4 sm:px-6 relative overflow-hidden"
      style={{ background: 'linear-gradient(135deg, #0F0F23 0%, #1a0a3e 50%, #0F0F23 100%)' }}>
      
      {/* Atmospheric glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] rounded-full translate-x-1/3 -translate-y-1/3" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-secondary/15 blur-[100px] rounded-full -translate-x-1/3 translate-y-1/3" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-accent/10 blur-[80px] rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Content */}
          <div className="reveal">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/8 border border-white/15 text-sm font-semibold text-white/90 mb-6">
              <Icon name="RocketLaunchIcon" size={14} className="text-accent" />
              Start Selling Today — Free
            </div>

            <h2 className="text-section-heading font-extrabold text-white mb-6 leading-tight">
              Turn Your Digital Skills Into{' '}
              <span style={{ background: 'linear-gradient(135deg, #FF3D57, #FF6B2B)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
                Real Revenue
              </span>
            </h2>

            <p className="text-white/70 text-lg leading-relaxed mb-8 max-w-lg">
              Join 14,000+ creators and enterprises selling on DigiMart. List your first product in under 5 minutes with zero upfront cost.
            </p>

            {/* Benefits List */}
            <div className="space-y-4 mb-10">
              {SELLER_BENEFITS.map((benefit, i) =>
              <div
                key={benefit.title}
                className={`flex items-start gap-4 reveal reveal-delay-${i + 1}`}>
                
                  <div className="w-10 h-10 rounded-xl bg-white/8 border border-white/10 flex items-center justify-center flex-shrink-0">
                    <Icon name={benefit.icon as 'CurrencyDollarIcon'} size={20} className="text-accent" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm mb-0.5">{benefit.title}</div>
                    <div className="text-white/60 text-sm leading-relaxed">{benefit.desc}</div>
                  </div>
                </div>
              )}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/products"
                className="btn-primary gap-2 !px-8 !py-3.5 !text-base">
                
                Start Selling Free
                <Icon name="ArrowRightIcon" size={18} />
              </Link>
              <Link
                href="/products"
                className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full border border-white/20 text-white text-base font-semibold hover:bg-white/8 transition-all">
                
                <Icon name="PlayCircleIcon" size={18} />
                See Seller Demo
              </Link>
            </div>
          </div>

          {/* Right: Stats + Image */}
          <div className="reveal reveal-delay-2">
            {/* Seller Stats Cards */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {SELLER_STATS.map((s) =>
              <div
                key={s.label}
                className="rounded-2xl p-4 text-center border border-white/10 hover:bg-white/8 transition-colors"
                style={{ background: 'rgba(255,255,255,0.05)' }}>
                
                  <div className="text-2xl font-extrabold text-white mb-1">{s.value}</div>
                  <div className="text-xs text-white/60 font-medium leading-snug">{s.label}</div>
                </div>
              )}
            </div>

            {/* Seller Dashboard Preview */}
            <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative">
              <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_12a259989-1766490417832.png"
                alt="Analytics dashboard showing sales charts with colorful graphs on dark screen in bright office"
                width={700}
                height={420}
                className="object-cover w-full" />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="glass-card rounded-xl p-4 border border-white/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-muted-foreground font-semibold mb-0.5">This Month&apos;s Earnings</div>
                      <div className="text-2xl font-extrabold text-foreground">$8,420.50</div>
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-green-50 border border-green-200">
                      <Icon name="ArrowTrendingUpIcon" size={14} className="text-green-600" />
                      <span className="text-xs font-bold text-green-600">+34% vs last month</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Social proof */}
            <div className="flex items-center gap-4 mt-5 pt-5 border-t border-white/10">
              <div className="flex -space-x-3">
                {[
                'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&q=80',
                'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80',
                'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80'].
                map((src, i) =>
                <div key={i} className="w-9 h-9 rounded-full border-2 border-foreground/20 overflow-hidden">
                    <AppImage
                    src={src}
                    alt={`Seller ${i + 1} profile photo`}
                    width={36}
                    height={36}
                    className="object-cover w-full h-full" />
                  
                  </div>
                )}
                <div className="w-9 h-9 rounded-full border-2 border-white/20 bg-white/10 flex items-center justify-center text-white text-xs font-bold">
                  +14K
                </div>
              </div>
              <div>
                <div className="text-white text-sm font-semibold">Join 14,000+ sellers</div>
                <div className="text-white/50 text-xs">Avg. seller earns $2,400/mo</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>);

}