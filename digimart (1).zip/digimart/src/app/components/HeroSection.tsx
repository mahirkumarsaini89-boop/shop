'use client';
import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

const FLOATING_CARDS = [
{
  id: 1,
  title: 'UI Kit Pro',
  category: 'Templates',
  price: '$49',
  rating: 4.9,
  sales: '12.4k',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1f5b4d3d4-1772202235094.png",
  alt: 'Colorful UI design components on dark screen with vibrant color swatches',
  color: 'from-primary to-accent',
  rotate: '-rotate-3',
  position: 'top-16 left-4 md:left-8'
},
{
  id: 2,
  title: 'Python Masterclass',
  category: 'Courses',
  price: '$79',
  rating: 4.8,
  sales: '8.2k',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_133de06b9-1772767374538.png",
  alt: 'Python code on bright monitor in modern workspace with clean desk setup',
  color: 'from-secondary to-purple-400',
  rotate: 'rotate-2',
  position: 'top-8 right-4 md:right-8'
},
{
  id: 3,
  title: 'Stock Music Bundle',
  category: 'Media',
  price: '$29',
  rating: 4.7,
  sales: '5.6k',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1b6e0c765-1764657697592.png",
  alt: 'Audio waveform visualization on screen with colorful equalizer bars',
  color: 'from-accent to-yellow-400',
  rotate: '-rotate-1',
  position: 'bottom-20 left-0 md:left-4'
}];


const LIVE_STATS = [
{ label: 'Products Sold Today', value: '2,847', icon: 'ShoppingBagIcon', color: 'text-primary' },
{ label: 'Active Sellers', value: '14,230', icon: 'UsersIcon', color: 'text-secondary' },
{ label: 'Revenue Today', value: '$124K', icon: 'CurrencyDollarIcon', color: 'text-accent' }];


export default function HeroSection() {
  const [activeStatIndex, setActiveStatIndex] = useState(0);
  const [mounted, setMounted] = useState(false);
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setMounted(true);
    const interval = setInterval(() => {
      setActiveStatIndex((prev) => (prev + 1) % LIVE_STATS?.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const isVisible = mounted;

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden grid-bg pt-24 pb-16">
      
      {/* Background Blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="blob-primary absolute w-96 h-96 top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 animate-blob opacity-60" />
        <div className="blob-secondary absolute w-80 h-80 top-1/3 right-1/4 translate-x-1/2 animate-blob opacity-50" style={{ animationDelay: '3s' }} />
        <div className="blob-accent absolute w-72 h-72 bottom-1/4 left-1/2 -translate-x-1/2 animate-blob opacity-40" style={{ animationDelay: '6s' }} />
        <div className="hero-glow absolute inset-0" />
      </div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 w-full">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
          {/* Left: Text Content */}
          <div className="flex-1 text-center lg:text-left max-w-2xl mx-auto lg:mx-0">
            {/* Badge */}
            <div
              className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-sm font-semibold text-primary mb-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
              500K+ Digital Products Available Now
            </div>

            {/* Headline */}
            <h1
              className={`text-hero-xl font-extrabold text-foreground mb-6 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
              
              The World&apos;s Best{' '}
              <span className="gradient-text">Digital</span>{' '}
              Marketplace
            </h1>

            {/* Subheadline */}
            <p
              className={`text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-xl mx-auto lg:mx-0 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
              
              Software, courses, templates, music, e-books — everything digital in one enterprise-grade platform. Instant delivery, global reach.
            </p>

            {/* CTAs */}
            <div
              className={`flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10 transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
              
              <Link href="/products" className="btn-primary text-base gap-2">
                Browse Products
                <Icon name="ArrowRightIcon" size={18} />
              </Link>
              <Link href="/products" className="btn-secondary text-base gap-2">
                <Icon name="PlayIcon" size={18} />
                Watch Demo
              </Link>
            </div>

            {/* Quick stats row */}
            <div
              className={`flex flex-wrap gap-6 justify-center lg:justify-start transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
              
              {[
              { label: 'Products', value: '500K+' },
              { label: 'Sellers', value: '14K+' },
              { label: 'Happy Buyers', value: '2M+' },
              { label: 'Countries', value: '120+' }]?.
              map((s) =>
              <div key={s?.label} className="text-center lg:text-left">
                  <div className="text-2xl font-extrabold text-foreground">{s?.value}</div>
                  <div className="text-xs text-muted-foreground font-medium mt-0.5">{s?.label}</div>
                </div>
              )}
            </div>
          </div>

          {/* Right: 3D Floating Product Cards */}
          <div className="flex-1 relative w-full max-w-lg mx-auto h-[500px] md:h-[580px] hidden sm:block">
            {/* Live Stats Counter Card (center) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 animate-float">
              <div className="glass-card rounded-2xl p-5 shadow-2xl w-64 border border-white/60">
                {/* Live indicator */}
                <div className="flex items-center gap-2 mb-4">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                  </span>
                  <span className="text-xs font-bold text-primary uppercase tracking-widest">Live Activity</span>
                </div>

                {/* Rotating stat */}
                <div className="min-h-[60px] flex flex-col justify-center">
                  <div className="text-3xl font-extrabold text-foreground tabular-nums animate-count-up" key={activeStatIndex}>
                    {LIVE_STATS?.[activeStatIndex]?.value}
                  </div>
                  <div className="text-sm text-muted-foreground font-medium mt-1">
                    {LIVE_STATS?.[activeStatIndex]?.label}
                  </div>
                </div>

                {/* Progress dots */}
                <div className="flex gap-1.5 mt-4">
                  {LIVE_STATS?.map((_, i) =>
                  <div
                    key={i}
                    className={`rounded-full transition-all duration-500 h-1.5 ${
                    i === activeStatIndex ? 'w-6 bg-primary' : 'w-1.5 bg-border'}`
                    } />

                  )}
                </div>
              </div>
            </div>

            {/* Floating Product Cards */}
            {FLOATING_CARDS?.map((card, i) =>
            <div
              key={card?.id}
              className={`absolute ${card?.position} z-10 ${i === 0 ? 'animate-float' : i === 1 ? 'animate-float-delayed' : 'animate-float'}`}
              style={{ animationDelay: `${i * 0.8}s` }}>
              
                <div className={`glass-card rounded-xl overflow-hidden shadow-xl w-44 md:w-52 ${card?.rotate} hover:scale-105 transition-transform duration-300 cursor-pointer`}>
                  <div className="h-28 overflow-hidden relative">
                    <AppImage
                    src={card?.image}
                    alt={card?.alt}
                    fill
                    className="object-cover"
                    sizes="208px" />
                  
                    <div className={`absolute inset-0 bg-gradient-to-t from-black/40 to-transparent`} />
                    <span className="absolute top-2 left-2 badge-new">{card?.category}</span>
                  </div>
                  <div className="p-3">
                    <div className="font-bold text-foreground text-sm truncate">{card?.title}</div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="font-extrabold text-primary text-sm">{card?.price}</span>
                      <div className="flex items-center gap-1">
                        <Icon name="StarIcon" size={12} className="text-yellow-400" variant="solid" />
                        <span className="text-xs text-muted-foreground">{card?.rating}</span>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{card?.sales} sold</div>
                  </div>
                </div>
              </div>
            )}

            {/* Decorative elements */}
            <div className="absolute bottom-8 right-8 w-20 h-20 rounded-full bg-primary/10 animate-blob" style={{ animationDelay: '2s' }} />
            <div className="absolute top-12 left-1/2 w-16 h-16 rounded-full bg-secondary/10 animate-blob" />
          </div>
        </div>
      </div>
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="text-xs text-muted-foreground font-medium">Scroll to explore</span>
        <Icon name="ChevronDownIcon" size={20} className="text-muted-foreground" />
      </div>
    </section>);

}