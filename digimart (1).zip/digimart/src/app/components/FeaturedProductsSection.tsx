'use client';
import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const FILTER_TABS = ['All', 'Software', 'Courses', 'Templates', 'E-Books', 'Media'];

const PRODUCTS = [
{
  id: 1,
  title: 'Figma Master UI Kit 2026',
  seller: 'DesignLab Studio',
  category: 'Templates',
  price: 49,
  originalPrice: 99,
  rating: 4.9,
  reviews: 2341,
  sales: '18.4K',
  badge: 'BESTSELLER',
  badgeType: 'sale',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1f5b4d3d4-1772202235094.png",
  alt: 'Figma UI components colorful design system on bright white background',
  tags: ['Templates']
},
{
  id: 2,
  title: 'Complete Python & ML Bootcamp',
  seller: 'CodeAcademy Pro',
  category: 'Courses',
  price: 79,
  originalPrice: 199,
  rating: 4.8,
  reviews: 5670,
  sales: '32.1K',
  badge: 'NEW',
  badgeType: 'new',
  image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",
  alt: 'Person coding Python on laptop with colorful code on bright screen',
  tags: ['Courses']
},
{
  id: 3,
  title: 'Adobe Photoshop 2026 License',
  seller: 'Adobe Official',
  category: 'Software',
  price: 239,
  originalPrice: 299,
  rating: 4.7,
  reviews: 8920,
  sales: '41.2K',
  badge: '20% OFF',
  badgeType: 'sale',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_126ea3997-1775566214731.png",
  alt: 'Photo editing software open with colorful landscape image on bright monitor',
  tags: ['Software']
},
{
  id: 4,
  title: 'Epic Stock Music Bundle Vol.3',
  seller: 'SoundForge Media',
  category: 'Media',
  price: 29,
  originalPrice: 59,
  rating: 4.6,
  reviews: 1230,
  sales: '7.8K',
  badge: 'HOT',
  badgeType: 'new',
  image: "https://images.unsplash.com/photo-1569965352022-f014c3ca4c5e",
  alt: 'Music production setup with colorful synthesizer and bright studio lighting',
  tags: ['Media']
},
{
  id: 5,
  title: 'The Startup Playbook 2026',
  seller: 'BizBook Publishers',
  category: 'E-Books',
  price: 19,
  originalPrice: 39,
  rating: 4.8,
  reviews: 892,
  sales: '4.3K',
  badge: 'TOP RATED',
  badgeType: 'sale',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1b47fea24-1772094007906.png",
  alt: 'Open book with business notes on bright minimalist desk with coffee',
  tags: ['E-Books']
},
{
  id: 6,
  title: 'React Next.js 15 Starter Kit',
  seller: 'DevBoilerplate',
  category: 'Software',
  price: 89,
  originalPrice: 149,
  rating: 4.9,
  reviews: 3410,
  sales: '22.7K',
  badge: 'BESTSELLER',
  badgeType: 'sale',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1a9c34057-1773184039056.png",
  alt: 'React code on bright monitor with component tree visualization',
  tags: ['Software']
},
{
  id: 7,
  title: 'Brand Identity Design Course',
  seller: 'Creative Academy',
  category: 'Courses',
  price: 59,
  originalPrice: 119,
  rating: 4.7,
  reviews: 1876,
  sales: '9.4K',
  badge: 'NEW',
  badgeType: 'new',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1f5d87104-1764656054680.png",
  alt: 'Brand design mockups with colorful logo variations on bright white workspace',
  tags: ['Courses']
},
{
  id: 8,
  title: 'Motion Graphics Pack 500+',
  seller: 'MotionLab',
  category: 'Media',
  price: 39,
  originalPrice: 89,
  rating: 4.5,
  reviews: 654,
  sales: '3.2K',
  badge: '56% OFF',
  badgeType: 'sale',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1089a773a-1772388847397.png",
  alt: 'Motion graphics animation frames on bright colorful background',
  tags: ['Media']
}];


export default function FeaturedProductsSection() {
  const [activeTab, setActiveTab] = useState('All');
  const [wishlist, setWishlist] = useState<number[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  const filtered = activeTab === 'All' ? PRODUCTS : PRODUCTS.filter((p) => p.tags.includes(activeTab));

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('active');
        });
      },
      { threshold: 0.05, rootMargin: '0px 0px -40px 0px' }
    );
    const reveals = sectionRef.current?.querySelectorAll('.reveal');
    reveals?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const toggleWishlist = (id: number) => {
    setWishlist((prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]);
  };

  return (
    <section ref={sectionRef} className="py-16 px-4 sm:px-6 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8 reveal">
          <div>
            <span className="text-xs font-bold text-primary uppercase tracking-widest mb-2 block">Featured Products</span>
            <h2 className="text-section-heading font-extrabold text-foreground">
              Top Sellers This{' '}
              <span className="gradient-text">Week</span>
            </h2>
          </div>
          <Link
            href="/products"
            className="flex items-center gap-2 text-sm font-semibold text-primary hover:gap-3 transition-all">
            
            View all products
            <Icon name="ArrowRightIcon" size={16} />
          </Link>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2 mb-8 reveal reveal-delay-1">
          {FILTER_TABS.map((tab) =>
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
            activeTab === tab ?
            'bg-primary text-primary-foreground shadow-lg shadow-primary/30' :
            'bg-card text-muted-foreground border border-border hover:border-primary hover:text-primary'}`
            }>
            
              {tab}
            </button>
          )}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filtered.map((product, i) =>
          <div
            key={product.id}
            className={`product-card reveal`}
            style={{ transitionDelay: `${i * 60}ms` }}>
            
              {/* Image */}
              <div className="relative h-44 overflow-hidden">
                <AppImage
                src={product.image}
                alt={product.alt}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw" />
              
                {/* Badge */}
                <span className={`absolute top-3 left-3 ${product.badgeType === 'new' ? 'badge-new' : 'badge-sale'}`}>
                  {product.badge}
                </span>
                {/* Wishlist */}
                <button
                onClick={() => toggleWishlist(product.id)}
                className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
                wishlist.includes(product.id) ?
                'bg-primary text-primary-foreground' :
                'bg-white/80 backdrop-blur-sm text-muted-foreground hover:text-primary'}`
                }
                aria-label={`${wishlist.includes(product.id) ? 'Remove from' : 'Add to'} wishlist`}>
                
                  <Icon
                  name="HeartIcon"
                  size={16}
                  variant={wishlist.includes(product.id) ? 'solid' : 'outline'} />
                
                </button>
                {/* Discount */}
                {product.originalPrice > product.price &&
              <div className="absolute bottom-3 right-3 bg-foreground/80 backdrop-blur-sm text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                  </div>
              }
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="text-xs text-muted-foreground font-medium mb-1">{product.seller}</div>
                <h3 className="font-bold text-foreground text-sm leading-snug mb-2 line-clamp-2">{product.title}</h3>

                {/* Rating */}
                <div className="flex items-center gap-1.5 mb-3">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) =>
                  <Icon
                    key={star}
                    name="StarIcon"
                    size={12}
                    className={star <= Math.floor(product.rating) ? 'text-yellow-400' : 'text-border'}
                    variant="solid" />

                  )}
                  </div>
                  <span className="text-xs font-semibold text-foreground">{product.rating}</span>
                  <span className="text-xs text-muted-foreground">({product.reviews.toLocaleString()})</span>
                </div>

                {/* Price + CTA */}
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-lg font-extrabold text-foreground">${product.price}</span>
                    {product.originalPrice > product.price &&
                  <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
                  }
                  </div>
                  <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-bold hover:bg-primary/90 transition-colors">
                    <Icon name="ShoppingCartIcon" size={14} />
                    Add
                  </button>
                </div>

                <div className="mt-2 text-xs text-muted-foreground font-medium">
                  {product.sales} downloads
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}