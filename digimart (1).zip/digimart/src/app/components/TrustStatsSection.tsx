'use client';
import React, { useEffect, useRef, useState } from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

const STATS = [
{ value: 500000, display: '500K+', label: 'Digital Products', suffix: '+', icon: 'CubeIcon', color: 'text-primary' },
{ value: 2000000, display: '2M+', label: 'Happy Customers', suffix: '+', icon: 'FaceSmileIcon', color: 'text-secondary' },
{ value: 14000, display: '14K+', label: 'Active Sellers', suffix: '+', icon: 'UsersIcon', color: 'text-accent' },
{ value: 120, display: '120+', label: 'Countries Served', suffix: '+', icon: 'GlobeAltIcon', color: 'text-primary' },
{ value: 99.9, display: '99.9%', label: 'Uptime SLA', suffix: '%', icon: 'ShieldCheckIcon', color: 'text-secondary' },
{ value: 4.8, display: '4.8★', label: 'Average Rating', suffix: '★', icon: 'StarIcon', color: 'text-accent' }];


const TESTIMONIALS = [
{
  id: 1,
  name: 'Marcus Johnson',
  role: 'Lead Developer, TechFlow Inc.',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1dc2c6b13-1763296937529.png",
  avatarAlt: 'Professional headshot of Marcus Johnson, developer, smiling in bright office',
  quote: 'DigiMart saved our team 40+ hours per sprint. The React starter kits and UI components are genuinely production-grade — not the usual recycled templates.',
  stars: 5,
  company: 'TechFlow Inc.',
  tag: 'Software'
},
{
  id: 2,
  name: 'Priya Sharma',
  role: 'Head of L&D, GlobalEdge Corp.',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_10d8e7d5e-1772203315807.png",
  avatarAlt: 'Professional headshot of Priya Sharma, HR professional, in bright conference room',
  quote: 'We bulk-licensed 12 courses for our 200-person engineering team. The B2B pricing was transparent, invoicing was instant, and the content quality exceeded expectations.',
  stars: 5,
  company: 'GlobalEdge Corp.',
  tag: 'Courses'
},
{
  id: 3,
  name: 'Liam O\'Brien',
  role: 'Creative Director, PixelDraft Agency',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_179bed4fe-1763291985213.png",
  avatarAlt: 'Professional headshot of Liam O\'Brien, creative director, in bright modern studio',
  quote: 'The design template collection is unmatched. Found a complete Figma system for our client rebrand in under 10 minutes. Saved 3 weeks of design work.',
  stars: 5,
  company: 'PixelDraft Agency',
  tag: 'Templates'
}];


function useCountUp(target: number, duration: number = 1800, isActive: boolean = false) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isActive) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration, isActive]);

  return count;
}

export default function TrustStatsSection() {
  const [statsActive, setStatsActive] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsActive(true);
            entry.target.querySelectorAll('.reveal').forEach((el) => el.classList.add('active'));
          }
        });
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 px-4 sm:px-6 bg-background overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="blob-secondary absolute w-96 h-96 -top-20 -right-20 opacity-30 animate-blob" />
        <div className="blob-primary absolute w-64 h-64 bottom-10 -left-10 opacity-20 animate-blob" style={{ animationDelay: '4s' }} />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-14 reveal">
          <span className="text-xs font-bold text-primary uppercase tracking-widest mb-2 block">By The Numbers</span>
          <h2 className="text-section-heading font-extrabold text-foreground mb-4">
            Trusted by <span className="gradient-text">2 Million+</span> Customers
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            From individual creators to Fortune 500 companies — DigiMart powers digital commerce at scale.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-16">
          {STATS.map((stat, i) =>
          <StatCard key={stat.label} stat={stat} isActive={statsActive} delay={i * 100} />
          )}
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) =>
          <div
            key={t.id}
            className={`reveal reveal-delay-${i + 1} bg-card rounded-2xl border border-border p-6 card-hover`}>
            
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[1, 2, 3, 4, 5].map((s) =>
              <Icon key={s} name="StarIcon" size={16} className="text-yellow-400" variant="solid" />
              )}
              </div>

              {/* Quote */}
              <blockquote className="text-sm text-foreground leading-relaxed font-medium mb-5">
                &ldquo;{t.quote}&rdquo;
              </blockquote>

              {/* Metrics badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/8 border border-primary/15 text-xs font-semibold text-primary mb-5">
                <Icon name="TagIcon" size={12} />
                {t.tag}
              </div>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-border flex-shrink-0">
                  <AppImage
                  src={t.avatar}
                  alt={t.avatarAlt}
                  width={40}
                  height={40}
                  className="object-cover w-full h-full" />
                
                </div>
                <div>
                  <div className="text-sm font-bold text-foreground">{t.name}</div>
                  <div className="text-xs text-muted-foreground font-medium">{t.role}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}

function StatCard({ stat, isActive, delay }: {stat: typeof STATS[0];isActive: boolean;delay: number;}) {
  const count = useCountUp(stat.value, 1800, isActive);

  const formatDisplay = () => {
    if (stat.value >= 1000000) return `${(count / 1000000).toFixed(1)}M+`;
    if (stat.value >= 1000) return `${(count / 1000).toFixed(0)}K+`;
    if (stat.suffix === '%' || stat.suffix === '★') return stat.display;
    return `${count}+`;
  };

  return (
    <div
      className={`stat-card text-center reveal`}
      style={{ transitionDelay: `${delay}ms` }}>
      
      <div className={`w-10 h-10 rounded-xl mx-auto mb-3 flex items-center justify-center bg-primary/8`}>
        <Icon name={stat.icon as 'CubeIcon'} size={20} className={stat.color} />
      </div>
      <div className={`text-2xl font-extrabold ${stat.color} tabular-nums`}>
        {isActive ? formatDisplay() : '0'}
      </div>
      <div className="text-xs text-muted-foreground font-medium mt-1">{stat.label}</div>
    </div>);

}