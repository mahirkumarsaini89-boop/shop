'use client';
import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const CATEGORIES = [
{
  id: 1,
  name: 'Software & Licenses',
  count: '142K+ products',
  description: 'Productivity apps, dev tools, security software & enterprise licenses',
  image: "https://images.unsplash.com/photo-1662638600507-0846616ec508",
  alt: 'Code editor on bright monitor with colorful syntax highlighting in modern office',
  icon: 'ComputerDesktopIcon',
  gradient: 'from-primary/80 to-accent/60',
  colSpan: 'md:col-span-2',
  rowSpan: 'md:row-span-2',
  tall: true
},
{
  id: 2,
  name: 'E-Books & Guides',
  count: '89K+ products',
  description: 'Business, tech, self-help & fiction',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_170011894-1772822439295.png",
  alt: 'Open books and tablet with bright reading lamp on clean wooden desk',
  icon: 'BookOpenIcon',
  gradient: 'from-secondary/80 to-purple-400/60',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  tall: false
},
{
  id: 3,
  name: 'Design Templates',
  count: '210K+ products',
  description: 'UI kits, Figma files, web templates',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_109ca890c-1772573757111.png",
  alt: 'Colorful design mockups and UI components on bright white workspace',
  icon: 'SwatchIcon',
  gradient: 'from-accent/80 to-yellow-400/60',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  tall: false
},
{
  id: 4,
  name: 'Music & Media',
  count: '67K+ products',
  description: 'Royalty-free music, SFX, video assets & stock footage',
  image: "https://images.unsplash.com/photo-1573216045300-c6b2aa798f8b",
  alt: 'Music studio with colorful LED lights and mixing console in bright room',
  icon: 'MusicalNoteIcon',
  gradient: 'from-pink-500/80 to-primary/60',
  colSpan: 'md:col-span-2',
  rowSpan: '',
  tall: false
},
{
  id: 5,
  name: 'Online Courses',
  count: '32K+ products',
  description: 'Video courses, workshops & certifications',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_141e08617-1772065990180.png",
  alt: 'Person watching online course on laptop with notes and coffee in bright home office',
  icon: 'AcademicCapIcon',
  gradient: 'from-secondary/80 to-blue-400/60',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  tall: false
},
{
  id: 6,
  name: 'Design Assets',
  count: '55K+ products',
  description: 'Icons, fonts, illustrations & 3D models',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_109ca890c-1772573757111.png",
  alt: 'Colorful icon set and design elements displayed on bright white background',
  icon: 'SparklesIcon',
  gradient: 'from-accent/80 to-orange-400/60',
  colSpan: 'md:col-span-1',
  rowSpan: '',
  tall: false
}];


export default function CategoryBentoSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const reveals = sectionRef.current?.querySelectorAll('.reveal');
    reveals?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 px-4 sm:px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-10 reveal">
          <div>
            <span className="text-xs font-bold text-primary uppercase tracking-widest mb-2 block">Browse Categories</span>
            <h2 className="text-section-heading font-extrabold text-foreground">
              Every Digital Product,{' '}
              <span className="gradient-text">One Place</span>
            </h2>
          </div>
          <Link
            href="/products"
            className="flex items-center gap-2 text-sm font-semibold text-primary hover:gap-3 transition-all duration-200">
            
            View all categories
            <Icon name="ArrowRightIcon" size={16} />
          </Link>
        </div>

        {/* Bento Grid */}
        {/* 
           BENTO GRID AUDIT:
           Array: [Software(cs-2 rs-2), E-Books(cs-1), Templates(cs-1), Music(cs-2), Courses(cs-1), DesignAssets(cs-1)]
           Row 1: [col-1,2: Software] [col-3: E-Books] [col-4: Templates]
           Row 2: [col-1,2: Software FILLED] [col-3,4: Music]
           Row 3: [col-1: Courses] [col-2: DesignAssets] — expand last row
           Placed 6/6 ✓
          */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {/* Software — col-span-2, row-span-2 */}
          {/* col-1,2: row 1+2 */}
          <div className={`md:col-span-2 md:row-span-2 reveal reveal-delay-1`}>
            <CategoryCard category={CATEGORIES[0]} tall />
          </div>

          {/* E-Books — col-3 row 1 */}
          <div className="reveal reveal-delay-2">
            <CategoryCard category={CATEGORIES[1]} tall={false} />
          </div>

          {/* Templates — col-4 row 1 */}
          <div className="reveal reveal-delay-3">
            <CategoryCard category={CATEGORIES[2]} tall={false} />
          </div>

          {/* Music — col-3,4 row 2 */}
          <div className="md:col-span-2 reveal reveal-delay-4">
            <CategoryCard category={CATEGORIES[3]} tall={false} />
          </div>

          {/* Courses — col-1 row 3 */}
          <div className="reveal reveal-delay-2">
            <CategoryCard category={CATEGORIES[4]} tall={false} />
          </div>

          {/* Design Assets — col-2,3,4 row 3 */}
          <div className="md:col-span-3 reveal reveal-delay-3">
            <CategoryCard category={CATEGORIES[5]} tall={false} />
          </div>
        </div>
      </div>
    </section>);

}

function CategoryCard({ category, tall }: {category: typeof CATEGORIES[0];tall: boolean;}) {
  return (
    <Link
      href="/products"
      className={`group relative overflow-hidden rounded-2xl block ${tall ? 'h-64 md:h-full min-h-[320px]' : 'h-48 sm:h-52'} cursor-pointer`}>
      
      {/* Background Image */}
      <AppImage
        src={category.image}
        alt={category.alt}
        fill
        className="object-cover transition-transform duration-700 group-hover:scale-110"
        sizes="(max-width: 768px) 100vw, 50vw" />
      

      {/* Gradient Overlay */}
      <div className={`absolute inset-0 bg-gradient-to-t ${category.gradient} opacity-80 group-hover:opacity-90 transition-opacity duration-300`} />

      {/* Content */}
      <div className="absolute inset-0 p-5 flex flex-col justify-end">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Icon name={category.icon as 'ComputerDesktopIcon'} size={18} className="text-white" />
          </div>
          <span className="text-xs font-semibold text-white/80 uppercase tracking-wider">{category.count}</span>
        </div>
        <h3 className="text-xl font-extrabold text-white leading-tight mb-1">{category.name}</h3>
        {tall &&
        <p className="text-sm text-white/80 font-medium leading-relaxed line-clamp-2">{category.description}</p>
        }
        <div className="flex items-center gap-1 mt-3 text-white/90 text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <span>Browse now</span>
          <Icon name="ArrowRightIcon" size={14} />
        </div>
      </div>
    </Link>);

}