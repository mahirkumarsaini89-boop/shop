import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductsPageClient from '@/app/products/components/ProductsPageClient';

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ProductsPageClient />
      <Footer />
    </main>
  );
}