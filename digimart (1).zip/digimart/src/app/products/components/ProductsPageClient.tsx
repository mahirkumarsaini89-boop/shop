'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const CATEGORIES_FILTER = ['All', 'Software', 'E-Books', 'Courses', 'Templates', 'Music & Media', 'Design Assets'];
const SORT_OPTIONS = ['Most Popular', 'Newest', 'Price: Low to High', 'Price: High to Low', 'Top Rated'];
const PRICE_RANGES = ['Any Price', 'Under $10', '$10–$50', '$50–$100', '$100–$250', 'Over $250'];
const RATINGS_FILTER = ['Any Rating', '4.5+ Stars', '4.0+ Stars', '3.5+ Stars'];
const LICENSE_TYPES = ['All Licenses', 'Personal Use', 'Commercial Use', 'Extended License', 'SaaS License'];

const ALL_PRODUCTS = [
{ id: 1, title: 'Figma Master UI Kit 2026', seller: 'DesignLab Studio', category: 'Templates', price: 49, originalPrice: 99, rating: 4.9, reviews: 2341, sales: '18.4K', badge: 'BESTSELLER', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1f5b4d3d4-1772202235094.png", alt: 'Figma UI kit with colorful components displayed on bright white screen', license: 'Commercial Use', fileType: 'Figma', updated: '2026-04-10', size: '245 MB' },
{ id: 2, title: 'Complete Python & ML Bootcamp', seller: 'CodeAcademy Pro', category: 'Courses', price: 79, originalPrice: 199, rating: 4.8, reviews: 5670, sales: '32.1K', badge: 'NEW', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1f024f936-1772098878507.png", alt: 'Python code on bright laptop screen with notebook and coffee on clean desk', license: 'Personal Use', fileType: 'Video', updated: '2026-05-01', size: '12.4 GB' },
{ id: 3, title: 'Adobe Photoshop 2026 License', seller: 'Adobe Official', category: 'Software', price: 239, originalPrice: 299, rating: 4.7, reviews: 8920, sales: '41.2K', badge: '20% OFF', image: "https://img.rocket.new/generatedImages/rocket_gen_img_126ea3997-1775566214731.png", alt: 'Photoshop interface with colorful photo editing tools on bright monitor', license: 'Commercial Use', fileType: 'Software', updated: '2026-03-15', size: '4.2 GB' },
{ id: 4, title: 'Epic Stock Music Bundle Vol.3', seller: 'SoundForge Media', category: 'Music & Media', price: 29, originalPrice: 59, rating: 4.6, reviews: 1230, sales: '7.8K', badge: 'HOT', image: "https://images.unsplash.com/photo-1568993703320-07e80bc8e7ab", alt: 'Music studio mixing console with colorful LED lights in bright modern studio', license: 'Commercial Use', fileType: 'MP3/WAV', updated: '2026-04-22', size: '2.1 GB' },
{ id: 5, title: 'The Startup Playbook 2026', seller: 'BizBook Publishers', category: 'E-Books', price: 19, originalPrice: 39, rating: 4.8, reviews: 892, sales: '4.3K', badge: 'TOP RATED', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1dc309cd6-1767870255499.png", alt: 'Open business book with highlighted notes on bright minimalist wooden desk', license: 'Personal Use', fileType: 'PDF/EPUB', updated: '2026-02-28', size: '14 MB' },
{ id: 6, title: 'React Next.js 15 Starter Kit', seller: 'DevBoilerplate', category: 'Templates', price: 89, originalPrice: 149, rating: 4.9, reviews: 3410, sales: '22.7K', badge: 'BESTSELLER', image: "https://images.unsplash.com/photo-1670057046254-3b5095eb4b66", alt: 'React components code on bright monitor with colorful UI preview', license: 'Commercial Use', fileType: 'ZIP', updated: '2026-05-05', size: '380 MB' },
{ id: 7, title: 'Brand Identity Design Course', seller: 'Creative Academy', category: 'Courses', price: 59, originalPrice: 119, rating: 4.7, reviews: 1876, sales: '9.4K', badge: 'NEW', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1ca96e216-1775714895623.png", alt: 'Brand identity mockups with colorful logo variations on bright studio desk', license: 'Personal Use', fileType: 'Video', updated: '2026-04-18', size: '8.7 GB' },
{ id: 8, title: 'Motion Graphics Pack 500+', seller: 'MotionLab', category: 'Music & Media', price: 39, originalPrice: 89, rating: 4.5, reviews: 654, sales: '3.2K', badge: '56% OFF', image: "https://img.rocket.new/generatedImages/rocket_gen_img_13ca69cab-1768494603594.png", alt: 'Motion graphics animation frames on vibrant colorful digital background', license: 'Commercial Use', fileType: 'AEP/MOV', updated: '2026-03-30', size: '5.6 GB' },
{ id: 9, title: 'VS Code Pro Extension Bundle', seller: 'CodeTools Hub', category: 'Software', price: 35, originalPrice: 70, rating: 4.6, reviews: 2100, sales: '15.3K', badge: 'HOT', image: "https://images.unsplash.com/photo-1670818587378-6851caa9969b", alt: 'VS Code editor with colorful syntax highlighting and extensions on bright screen', license: 'Commercial Use', fileType: 'Software', updated: '2026-05-02', size: '120 MB' },
{ id: 10, title: 'Notion Business Templates 2026', seller: 'ProductivityPro', category: 'Templates', price: 24, originalPrice: 49, rating: 4.8, reviews: 3200, sales: '28.9K', badge: 'TOP RATED', image: "https://img.rocket.new/generatedImages/rocket_gen_img_11003c8b0-1773211912290.png", alt: 'Notion productivity templates displayed on bright laptop with organized workspace', license: 'Personal Use', fileType: 'Notion', updated: '2026-04-25', size: '5 MB' },
{ id: 11, title: 'Digital Marketing Masterclass', seller: 'GrowthHack Academy', category: 'Courses', price: 99, originalPrice: 249, rating: 4.9, reviews: 4560, sales: '19.8K', badge: 'BESTSELLER', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1cdb08555-1772648849383.png", alt: 'Marketing analytics dashboard on bright laptop with growth charts', license: 'Personal Use', fileType: 'Video', updated: '2026-05-08', size: '15.2 GB' },
{ id: 12, title: 'Premium Icon Pack 10,000+', seller: 'IconForge', category: 'Design Assets', price: 29, originalPrice: 59, rating: 4.7, reviews: 1890, sales: '11.4K', badge: 'NEW', image: "https://img.rocket.new/generatedImages/rocket_gen_img_10778eb0b-1767612547489.png", alt: 'Colorful icon set displayed in organized grid on bright white background', license: 'Commercial Use', fileType: 'SVG/PNG', updated: '2026-04-12', size: '890 MB' },
{ id: 13, title: 'Cybersecurity Fundamentals', seller: 'SecureLearn', category: 'Courses', price: 69, originalPrice: 149, rating: 4.6, reviews: 2230, sales: '8.1K', badge: '54% OFF', image: "https://img.rocket.new/generatedImages/rocket_gen_img_14b58766a-1772406733609.png", alt: 'Cybersecurity code on dark monitor with lock icons in bright modern workspace', license: 'Personal Use', fileType: 'Video', updated: '2026-03-20', size: '10.3 GB' },
{ id: 14, title: 'Tailwind CSS Component Library', seller: 'UIComponents.dev', category: 'Templates', price: 69, originalPrice: 139, rating: 4.8, reviews: 4100, sales: '25.6K', badge: 'BESTSELLER', image: "https://images.unsplash.com/photo-1652461906318-048e40e997cf", alt: 'Tailwind CSS components displayed on bright laptop screen with colorful UI cards', license: 'Commercial Use', fileType: 'HTML/CSS', updated: '2026-05-03', size: '156 MB' },
{ id: 15, title: 'Ambient Music & Lo-Fi Pack', seller: 'ChillBeats Studio', category: 'Music & Media', price: 15, originalPrice: 35, rating: 4.5, reviews: 780, sales: '5.9K', badge: 'HOT', image: "https://images.unsplash.com/photo-1730806200163-f2d1a6ec3514", alt: 'Cozy music production setup with warm ambient lighting and synthesizer keys', license: 'Commercial Use', fileType: 'MP3/WAV', updated: '2026-04-08', size: '1.4 GB' },
{ id: 16, title: 'Financial Freedom E-Book Bundle', seller: 'WealthMind Press', category: 'E-Books', price: 29, originalPrice: 59, rating: 4.7, reviews: 1340, sales: '6.7K', badge: 'TOP RATED', image: "https://img.rocket.new/generatedImages/rocket_gen_img_1cfbdfa01-1767435773329.png", alt: 'Finance books and charts on bright desk with calculator and coffee', license: 'Personal Use', fileType: 'PDF/EPUB', updated: '2026-02-15', size: '48 MB' }];


export default function ProductsPageClient() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeSort, setActiveSort] = useState('Most Popular');
  const [activePriceRange, setActivePriceRange] = useState('Any Price');
  const [activeRating, setActiveRating] = useState('Any Rating');
  const [activeLicense, setActiveLicense] = useState('All Licenses');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 12;

  const filtered = ALL_PRODUCTS.filter((p) => {
    const catMatch = activeCategory === 'All' || p.category === activeCategory;
    const priceMatch = (() => {
      if (activePriceRange === 'Any Price') return true;
      if (activePriceRange === 'Under $10') return p.price < 10;
      if (activePriceRange === '$10–$50') return p.price >= 10 && p.price <= 50;
      if (activePriceRange === '$50–$100') return p.price > 50 && p.price <= 100;
      if (activePriceRange === '$100–$250') return p.price > 100 && p.price <= 250;
      if (activePriceRange === 'Over $250') return p.price > 250;
      return true;
    })();
    const ratingMatch = (() => {
      if (activeRating === 'Any Rating') return true;
      if (activeRating === '4.5+ Stars') return p.rating >= 4.5;
      if (activeRating === '4.0+ Stars') return p.rating >= 4.0;
      if (activeRating === '3.5+ Stars') return p.rating >= 3.5;
      return true;
    })();
    const licenseMatch = activeLicense === 'All Licenses' || p.license === activeLicense;
    return catMatch && priceMatch && ratingMatch && licenseMatch;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (activeSort === 'Price: Low to High') return a.price - b.price;
    if (activeSort === 'Price: High to Low') return b.price - a.price;
    if (activeSort === 'Top Rated') return b.rating - a.rating;
    if (activeSort === 'Newest') return b.id - a.id;
    return parseFloat(b.sales) - parseFloat(a.sales);
  });

  const totalPages = Math.ceil(sorted.length / ITEMS_PER_PAGE);
  const paginated = sorted.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const toggleWishlist = (id: number) => {
    setWishlist((prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]);
  };

  const activeFilters = [
  activeCategory !== 'All' && activeCategory,
  activePriceRange !== 'Any Price' && activePriceRange,
  activeRating !== 'Any Rating' && activeRating,
  activeLicense !== 'All Licenses' && activeLicense].
  filter(Boolean) as string[];

  useEffect(() => {setCurrentPage(1);}, [activeCategory, activePriceRange, activeRating, activeLicense, activeSort]);

  return (
    <div className="pt-20 min-h-screen bg-background">
      {/* Page Header */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent py-12 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <nav className="flex items-center gap-2 text-sm text-white/70 mb-4">
            <Link href="/" className="hover:text-white transition-colors font-medium">Home</Link>
            <Icon name="ChevronRightIcon" size={14} />
            <span className="text-white font-semibold">All Products</span>
          </nav>
          <h1 className="text-3xl md:text-4xl font-extrabold text-white mb-2">Digital Products Marketplace</h1>
          <p className="text-white/80 text-lg font-medium">{ALL_PRODUCTS.length}+ premium digital products — instant delivery worldwide</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Mobile Filter Toggle */}
        <button
          className="md:hidden flex items-center gap-2 mb-4 px-4 py-2.5 rounded-xl border border-border bg-card text-sm font-semibold text-foreground"
          onClick={() => setSidebarOpen(!sidebarOpen)}>
          
          <Icon name="AdjustmentsHorizontalIcon" size={18} />
          Filters {activeFilters.length > 0 && `(${activeFilters.length})`}
        </button>

        <div className="flex gap-8">
          {/* Sidebar Filters */}
          <aside
            className={`${sidebarOpen ? 'block' : 'hidden'} md:block w-full md:w-60 lg:w-64 flex-shrink-0`}>
            
            <div className="sticky top-24 space-y-6">
              {/* Categories */}
              <FilterSection title="Categories">
                {CATEGORIES_FILTER.map((cat) =>
                <button
                  key={cat}
                  onClick={() => {setActiveCategory(cat);setSidebarOpen(false);}}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeCategory === cat ?
                  'bg-primary/10 text-primary font-bold border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`
                  }>
                  
                    {cat}
                  </button>
                )}
              </FilterSection>

              {/* Price */}
              <FilterSection title="Price Range">
                {PRICE_RANGES.map((range) =>
                <button
                  key={range}
                  onClick={() => setActivePriceRange(range)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  activePriceRange === range ?
                  'bg-primary/10 text-primary font-bold border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`
                  }>
                  
                    {range}
                  </button>
                )}
              </FilterSection>

              {/* Rating */}
              <FilterSection title="Rating">
                {RATINGS_FILTER.map((r) =>
                <button
                  key={r}
                  onClick={() => setActiveRating(r)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                  activeRating === r ?
                  'bg-primary/10 text-primary font-bold border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`
                  }>
                  
                    {r !== 'Any Rating' && <Icon name="StarIcon" size={12} className="text-yellow-400" variant="solid" />}
                    {r}
                  </button>
                )}
              </FilterSection>

              {/* License */}
              <FilterSection title="License Type">
                {LICENSE_TYPES.map((lic) =>
                <button
                  key={lic}
                  onClick={() => setActiveLicense(lic)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeLicense === lic ?
                  'bg-primary/10 text-primary font-bold border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`
                  }>
                  
                    {lic}
                  </button>
                )}
              </FilterSection>

              {/* Clear Filters */}
              {activeFilters.length > 0 &&
              <button
                onClick={() => {
                  setActiveCategory('All');
                  setActivePriceRange('Any Price');
                  setActiveRating('Any Rating');
                  setActiveLicense('All Licenses');
                }}
                className="w-full px-4 py-2.5 rounded-xl border border-primary/30 text-primary text-sm font-600 hover:bg-primary/5 transition-colors">
                
                  Clear All Filters
                </button>
              }
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Top Bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div>
                <span className="text-foreground font-700">{sorted.length} products</span>
                {activeFilters.length > 0 &&
                <div className="flex flex-wrap gap-2 mt-2">
                    {activeFilters.map((f) =>
                  <span key={f} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs font-600 border border-primary/20">
                        {f}
                        <button
                      onClick={() => {
                        if (CATEGORIES_FILTER.includes(f)) setActiveCategory('All');else
                        if (PRICE_RANGES.includes(f)) setActivePriceRange('Any Price');else
                        if (RATINGS_FILTER.includes(f)) setActiveRating('Any Rating');else
                        setActiveLicense('All Licenses');
                      }}
                      className="ml-0.5 hover:text-primary/70"
                      aria-label={`Remove filter ${f}`}>
                      
                          <Icon name="XMarkIcon" size={12} />
                        </button>
                      </span>
                  )}
                  </div>
                }
              </div>

              <div className="flex items-center gap-3">
                {/* Sort */}
                <select
                  value={activeSort}
                  onChange={(e) => setActiveSort(e.target.value)}
                  className="px-3 py-2 rounded-lg border border-border bg-card text-sm font-500 text-foreground focus:outline-none focus:border-primary"
                  aria-label="Sort products">
                  
                  {SORT_OPTIONS.map((o) =>
                  <option key={o} value={o}>{o}</option>
                  )}
                </select>

                {/* View Toggle */}
                <div className="flex rounded-lg border border-border overflow-hidden">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2.5 ${viewMode === 'grid' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:text-foreground'}`}
                    aria-label="Grid view">
                    
                    <Icon name="Squares2X2Icon" size={18} />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2.5 ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:text-foreground'}`}
                    aria-label="List view">
                    
                    <Icon name="ListBulletIcon" size={18} />
                  </button>
                </div>
              </div>
            </div>

            {/* Products */}
            {paginated.length === 0 ?
            <div className="flex flex-col items-center justify-center py-20 text-center">
                <Icon name="MagnifyingGlassIcon" size={48} className="text-muted-foreground/40 mb-4" />
                <h3 className="text-xl font-700 text-foreground mb-2">No products found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your filters to find what you&apos;re looking for.</p>
                <button
                onClick={() => {setActiveCategory('All');setActivePriceRange('Any Price');setActiveRating('Any Rating');setActiveLicense('All Licenses');}}
                className="btn-primary">
                
                  Clear Filters
                </button>
              </div> :
            viewMode === 'grid' ?
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {paginated.map((product) =>
              <ProductGridCard
                key={product.id}
                product={product}
                isWishlisted={wishlist.includes(product.id)}
                onWishlist={() => toggleWishlist(product.id)} />

              )}
              </div> :

            <div className="flex flex-col gap-4">
                {paginated.map((product) =>
              <ProductListCard
                key={product.id}
                product={product}
                isWishlisted={wishlist.includes(product.id)}
                onWishlist={() => toggleWishlist(product.id)} />

              )}
              </div>
            }

            {/* Pagination */}
            {totalPages > 1 &&
            <div className="flex items-center justify-center gap-2 mt-10">
                <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg border border-border bg-card text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                aria-label="Previous page">
                
                  <Icon name="ChevronLeftIcon" size={18} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) =>
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-9 h-9 rounded-lg text-sm font-600 transition-all ${
                page === currentPage ?
                'bg-primary text-primary-foreground shadow-lg shadow-primary/30' :
                'border border-border bg-card text-muted-foreground hover:text-foreground hover:border-primary'}`
                }
                aria-label={`Page ${page}`}
                aria-current={page === currentPage ? 'page' : undefined}>
                
                    {page}
                  </button>
              )}
                <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-2 rounded-lg border border-border bg-card text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                aria-label="Next page">
                
                  <Icon name="ChevronRightIcon" size={18} />
                </button>
              </div>
            }
          </div>
        </div>
      </div>
    </div>);

}

function FilterSection({ title, children }: {title: string;children: React.ReactNode;}) {
  return (
    <div className="bg-card rounded-xl border border-border p-4">
      <h3 className="text-sm font-700 text-foreground mb-3 uppercase tracking-wider">{title}</h3>
      <div className="space-y-1">{children}</div>
    </div>);

}

type Product = typeof ALL_PRODUCTS[0];

function ProductGridCard({ product, isWishlisted, onWishlist }: {product: Product;isWishlisted: boolean;onWishlist: () => void;}) {
  const discount = product.originalPrice > product.price ?
  Math.round((1 - product.price / product.originalPrice) * 100) :
  0;

  return (
    <div className="product-card group">
      <div className="relative h-48 overflow-hidden">
        <AppImage
          src={product.image}
          alt={product.alt}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          sizes="(max-width: 640px) 100vw, (max-width: 1280px) 50vw, 33vw" />
        
        <span className="absolute top-3 left-3 badge-sale">{product.badge}</span>
        <button
          onClick={onWishlist}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
          isWishlisted ? 'bg-primary text-primary-foreground' : 'bg-white/80 backdrop-blur-sm text-muted-foreground hover:text-primary'}`
          }
          aria-label={`${isWishlisted ? 'Remove from' : 'Add to'} wishlist`}>
          
          <Icon name="HeartIcon" size={16} variant={isWishlisted ? 'solid' : 'outline'} />
        </button>
        {discount > 0 &&
        <div className="absolute bottom-3 right-3 bg-foreground/80 text-white text-xs font-700 px-2 py-0.5 rounded-full">
            -{discount}%
          </div>
        }
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-muted-foreground font-500">{product.seller}</span>
          <span className="text-xs bg-muted px-2 py-0.5 rounded-full font-500 text-muted-foreground">{product.fileType}</span>
        </div>
        <h3 className="font-700 text-foreground text-sm leading-snug mb-2 line-clamp-2">{product.title}</h3>
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex">
            {[1, 2, 3, 4, 5].map((s) =>
            <Icon key={s} name="StarIcon" size={11} className={s <= Math.floor(product.rating) ? 'text-yellow-400' : 'text-border'} variant="solid" />
            )}
          </div>
          <span className="text-xs font-600 text-foreground">{product.rating}</span>
          <span className="text-xs text-muted-foreground">({product.reviews.toLocaleString()})</span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-800 text-foreground">${product.price}</span>
            {product.originalPrice > product.price &&
            <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
            }
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-700 hover:bg-primary/90 active:scale-95 transition-all">
            <Icon name="ShoppingCartIcon" size={14} />
            Add to Cart
          </button>
        </div>
        <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
          <span>{product.sales} downloads</span>
          <span>{product.license}</span>
        </div>
      </div>
    </div>);

}

function ProductListCard({ product, isWishlisted, onWishlist }: {product: Product;isWishlisted: boolean;onWishlist: () => void;}) {
  const discount = product.originalPrice > product.price ?
  Math.round((1 - product.price / product.originalPrice) * 100) :
  0;

  return (
    <div className="bg-card rounded-2xl border border-border p-4 flex gap-4 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 group">
      <div className="relative w-24 h-24 sm:w-32 sm:h-28 rounded-xl overflow-hidden flex-shrink-0">
        <AppImage
          src={product.image}
          alt={product.alt}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          sizes="128px" />
        
        {discount > 0 &&
        <div className="absolute top-1 left-1 bg-primary text-primary-foreground text-xs font-700 px-1.5 py-0.5 rounded-full">
            -{discount}%
          </div>
        }
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs text-muted-foreground font-500">{product.seller}</span>
              <span className="text-xs bg-muted px-2 py-0.5 rounded-full font-500 text-muted-foreground">{product.category}</span>
            </div>
            <h3 className="font-700 text-foreground text-base leading-snug mb-1 truncate">{product.title}</h3>
            <div className="flex items-center gap-1.5 mb-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((s) =>
                <Icon key={s} name="StarIcon" size={12} className={s <= Math.floor(product.rating) ? 'text-yellow-400' : 'text-border'} variant="solid" />
                )}
              </div>
              <span className="text-xs font-600 text-foreground">{product.rating}</span>
              <span className="text-xs text-muted-foreground">({product.reviews.toLocaleString()})</span>
              <span className="text-xs text-muted-foreground">• {product.sales} sales</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Icon name="DocumentArrowDownIcon" size={12} />{product.fileType}</span>
              <span className="flex items-center gap-1"><Icon name="ShieldCheckIcon" size={12} />{product.license}</span>
              <span className="hidden sm:flex items-center gap-1"><Icon name="ArchiveBoxIcon" size={12} />{product.size}</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 flex-shrink-0">
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-800 text-foreground">${product.price}</span>
              {product.originalPrice > product.price &&
              <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
              }
            </div>
            <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-700 hover:bg-primary/90 active:scale-95 transition-all">
              <Icon name="ShoppingCartIcon" size={14} />
              Add to Cart
            </button>
            <button
              onClick={onWishlist}
              className={`flex items-center gap-1 text-xs font-500 transition-colors ${isWishlisted ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}
              aria-label={`${isWishlisted ? 'Remove from' : 'Add to'} wishlist`}>
              
              <Icon name="HeartIcon" size={14} variant={isWishlisted ? 'solid' : 'outline'} />
              {isWishlisted ? 'Saved' : 'Save'}
            </button>
          </div>
        </div>
      </div>
    </div>);

}