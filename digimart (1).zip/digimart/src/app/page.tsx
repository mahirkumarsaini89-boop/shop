import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/app/components/HeroSection';
import CategoryBentoSection from '@/app/components/CategoryBentoSection';
import FeaturedProductsSection from '@/app/components/FeaturedProductsSection';
import TrustStatsSection from '@/app/components/TrustStatsSection';
import SellerCTASection from '@/app/components/SellerCTASection';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />
      <HeroSection />
      <CategoryBentoSection />
      <FeaturedProductsSection />
      <TrustStatsSection />
      <SellerCTASection />
      <Footer />
    </main>
  );
}